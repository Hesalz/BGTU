<?php
defined('_JEXEC') or die;

// Генерируем случайные числа для капчи
$num1 = rand(1, 10);
$num2 = rand(1, 10);
?>

<div id="compact-contact-<?php echo $module->id; ?>" class="compact-contact-module">
    <button type="button" class="contact-toggle-btn" onclick="toggleContactForm<?php echo $module->id; ?>()">
        📧 Контактная форма
    </button>
    
    <div class="contact-form-wrapper" id="contact-form-<?php echo $module->id; ?>" style="display: none;">
        <form onsubmit="return submitContactForm<?php echo $module->id; ?>()">
            <div class="input-field">
                <input type="text" name="name" placeholder="Ваше имя" required>
            </div>
            
            <div class="input-field">
                <input type="email" name="email" placeholder="Ваш email" required>
            </div>
            
            <div class="input-field">
                <textarea name="message" placeholder="Текст обращения" rows="4" required></textarea>
            </div>
            
            <div class="captcha-section">
                <strong>Вопрос: <?php echo $num1; ?> + <?php echo $num2; ?> = ?</strong>
                <input type="hidden" id="num1-<?php echo $module->id; ?>" value="<?php echo $num1; ?>">
                <input type="hidden" id="num2-<?php echo $module->id; ?>" value="<?php echo $num2; ?>">
                <input type="number" id="captcha-answer-<?php echo $module->id; ?>" placeholder="Ответ" required>
            </div>
            
            <button type="submit" class="submit-btn">Отправить сообщение</button>
        </form>
    </div>
</div>

<style>
.compact-contact-module {
    max-width: 350px;
    margin: 10px;
    font-family: Arial, sans-serif;
}

.contact-toggle-btn {
    background: #2E8B57;
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 6px;
    cursor: pointer;
    width: 100%;
    font-size: 16px;
    font-weight: bold;
}

.contact-toggle-btn:hover {
    background: #228B22;
}

.contact-form-wrapper {
    background: #f8f9fa;
    padding: 20px;
    border: 2px solid #2E8B57;
    border-radius: 8px;
    margin-top: 10px;
}

.input-field {
    margin-bottom: 15px;
}

.input-field input,
.input-field textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    box-sizing: border-box;
    font-size: 14px;
}

.captcha-section {
    background: #e8f5e8;
    padding: 15px;
    border-radius: 5px;
    margin: 15px 0;
    text-align: center;
}

.captcha-section input[type="number"] {
    margin-top: 10px;
    text-align: center;
    font-size: 16px;
    width: 100px;
    padding: 8px;
}

.submit-btn {
    background: #4169E1;
    color: white;
    border: none;
    padding: 12px;
    border-radius: 5px;
    cursor: pointer;
    width: 100%;
    font-size: 16px;
    font-weight: bold;
}

.submit-btn:hover {
    background: #3151C7;
}
</style>

<script>
function toggleContactForm<?php echo $module->id; ?>() {
    var form = document.getElementById('contact-form-<?php echo $module->id; ?>');
    if (form.style.display === 'none') {
        form.style.display = 'block';
    } else {
        form.style.display = 'none';
    }
}

function submitContactForm<?php echo $module->id; ?>() {
    var num1 = parseInt(document.getElementById('num1-<?php echo $module->id; ?>').value);
    var num2 = parseInt(document.getElementById('num2-<?php echo $module->id; ?>').value);
    var answer = parseInt(document.getElementById('captcha-answer-<?php echo $module->id; ?>').value);
    
    if (isNaN(answer)) {
        alert('Пожалуйста, введите ответ на вопрос');
        return false;
    }
    
    if ((num1 + num2) !== answer) {
        alert('Ошибка: Неправильный ответ! Правильный ответ: ' + (num1 + num2));
        return false;
    }
    
    alert('Сообщение успешно отправлено! (Это демо)');
    document.querySelector('#contact-form-<?php echo $module->id; ?> form').reset();
    toggleContactForm<?php echo $module->id; ?>();
    return false;
}
</script>