<?php
defined('_JEXEC') or die;

// Подключаем шаблон
require JModuleHelper::getLayoutPath('mod_compact_contact', $params->get('layout', 'default'));