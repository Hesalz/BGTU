<?php

namespace Drupal\computed_field\Plugin\Field\FieldType;

use Drupal\Core\Field\FieldItemBase;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\TypedData\DataDefinition;

/**
 * @FieldType(
 *   id = "simple_computed",
 *   label = @Translation("Simple Computed Field"),
 *   description = @Translation("Computed value from other fields."),
 *   default_widget = "string_textfield",
 *   default_formatter = "simple_computed_formatter"
 * )
 */
class SimpleComputedItem extends FieldItemBase {

  public static function propertyDefinitions(FieldStorageDefinitionInterface $definition) {
    $properties['value'] = DataDefinition::create('string')
      ->setLabel(t('Value'));
    return $properties;
  }

  public static function schema(FieldStorageDefinitionInterface $definition) {
    return [
      'columns' => [
        'value' => [
          'type' => 'varchar',
          'length' => 255,
        ],
      ],
    ];
  }

  public function preSave() {
    $node = $this->getEntity();
    $a = $node->get('field_a')->value ?? '';
    $b = $node->get('field_b')->value ?? '';
    $this->set('value', $a . ' ' . $b);
  }
}
