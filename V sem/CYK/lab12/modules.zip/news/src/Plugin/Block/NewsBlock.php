<?php

namespace Drupal\news\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'News Block' block.
 *
 * @Block(
 *   id = "news_block",
 *   admin_label = @Translation("News Block"),
 *   category = @Translation("Custom Blocks")
 * )
 */
class NewsBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#markup' => '<div class="news-block">This is a news block</div>',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheMaxAge() {
    return 0;
  }

}