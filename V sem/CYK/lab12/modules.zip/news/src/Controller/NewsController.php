<?php

namespace Drupal\news\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Controller for News module.
 */
class NewsController extends ControllerBase {

  /**
   * Display admin page.
   */
  public function adminPage() {
    return [
      '#markup' => '<h1>News Configuration</h1><p>This is the News administration page.</p>',
    ];
  }

}