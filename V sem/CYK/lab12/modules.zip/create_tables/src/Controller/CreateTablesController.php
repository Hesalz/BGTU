<?php

namespace Drupal\create_tables\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;

/**
 * Controller for Create Tables module.
 */
class CreateTablesController extends ControllerBase {

  /**
   * Display data from example table.
   */
  public function viewData() {
    $database = Database::getConnection();
    
    try {
      // Проверяем существование таблицы
      if (!$database->schema()->tableExists('create_tables_example')) {
        return [
          '#markup' => '<p>Table does not exist yet. Please reinstall module.</p>',
        ];
      }
      
      // Получаем данные
      $query = $database->select('create_tables_example', 'cte');
      $query->fields('cte', ['id', 'title', 'created']);
      $results = $query->execute()->fetchAll();
      
      $rows = [];
      foreach ($results as $row) {
        $rows[] = [
          $row->id,
          $row->title,
          date('Y-m-d H:i:s', $row->created),
        ];
      }
      
      $header = ['ID', 'Title', 'Created'];
      
      $build = [
        '#type' => 'table',
        '#header' => $header,
        '#rows' => $rows,
        '#empty' => $this->t('No data available.'),
      ];
      
      return $build;
    }
    catch (\Exception $e) {
      \Drupal::messenger()->addError('Error: ' . $e->getMessage());
      return [
        '#markup' => '<p>Error accessing database.</p>',
      ];
    }
  }

  /**
   * Simple test page.
   */
  public function testPage() {
    return [
      '#markup' => '<h2>Create Tables Module</h2><p>Module is working. Table "create_tables_example" should be created.</p>',
    ];
  }

}