﻿using System.Data.Entity;

namespace CarShopWPF.Models
{
    public class CarContext : DbContext
    {
        public CarContext() : base("name=CarShopDB")
        {
            Database.SetInitializer(new CarDbInitializer());
        }

        public DbSet<Car> Cars { get; set; }
        public DbSet<CarCategory> Categories { get; set; }
        public DbSet<CarImage> CarImages { get; set; }

        private class CarDbInitializer : CreateDatabaseIfNotExists<CarContext>
        {
            protected override void Seed(CarContext context)
            {
                context.Categories.Add(new CarCategory { Name = "Седан" });
                context.Categories.Add(new CarCategory { Name = "Хэтчбек" });
                context.Categories.Add(new CarCategory { Name = "Спорткар" });
                context.Categories.Add(new CarCategory { Name = "Кабриолет" });
                context.Categories.Add(new CarCategory { Name = "Кроссовер" });

                context.SaveChanges();

                base.Seed(context);
            }
        }
    }
}