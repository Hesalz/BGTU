﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CarShopWPF.Models
{
    public class CarCategory
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public virtual ICollection<Car> Cars { get; set; }
    }
}