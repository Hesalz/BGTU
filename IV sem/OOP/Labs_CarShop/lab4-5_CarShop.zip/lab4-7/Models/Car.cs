﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CarShopWPF.Models
{
    public class Car
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string ShortName { get; set; }
        public string FullName { get; set; }
        public string Description { get; set; }
        public virtual ICollection<CarImage> Images { get; set; } = new List<CarImage>();

        [ForeignKey("CarCategory")]
        public int CategoryId { get; set; }
        public virtual CarCategory CarCategory { get; set; }

        public double Rating { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public string Color { get; set; }
        public string Size { get; set; }
        public string CountryOfDelivery { get; set; }
        public decimal Discount { get; set; }
        public bool IsOutOfStock { get; set; }
        public virtual ICollection<Car> RelatedCars { get; set; }
        public int PurchasedCount { get; set; }
        public string Manufacturer { get; set; }
    }
}