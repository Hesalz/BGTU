﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using CarShopWPF.Models;

namespace CarShopWPF.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        internal CarContext _context = new CarContext();
        public ObservableCollection<Car> Cars { get; set; }
        public ObservableCollection<CarCategory> Categories { get; set; }

        private ObservableCollection<Car> _filteredCars;
        public ObservableCollection<Car> FilteredCars
        {
            get => _filteredCars;
            set { _filteredCars = value; OnPropertyChanged(nameof(FilteredCars)); }
        }

        private Car _selectedCar;
        public Car SelectedCar
        {
            get => _selectedCar;
            set { _selectedCar = value; OnPropertyChanged(nameof(SelectedCar)); }
        }

        private string _searchText;
        public string SearchText
        {
            get => _searchText;
            set { _searchText = value; OnPropertyChanged(nameof(SearchText)); FilterCars(); }
        }

        private CarCategory _selectedCategory;
        public CarCategory SelectedCategory
        {
            get => _selectedCategory;
            set { _selectedCategory = value; OnPropertyChanged(nameof(SelectedCategory)); FilterCars(); }
        }

        private decimal? _priceFrom;
        public decimal? PriceFrom
        {
            get => _priceFrom;
            set { _priceFrom = value; OnPropertyChanged(nameof(PriceFrom)); FilterCars(); }
        }

        private decimal? _priceTo;
        public decimal? PriceTo
        {
            get => _priceTo;
            set { _priceTo = value; OnPropertyChanged(nameof(PriceTo)); FilterCars(); }
        }

        private string _priceFromText;
        public string PriceFromText
        {
            get => _priceFromText;
            set
            {
                _priceFromText = value;
                if (decimal.TryParse(value, out decimal result))
                    PriceFrom = result;
                else
                    PriceFrom = null;
                OnPropertyChanged(nameof(PriceFromText));
                FilterCars();
            }
        }

        private string _priceToText;
        public string PriceToText
        {
            get => _priceToText;
            set
            {
                _priceToText = value;
                if (decimal.TryParse(value, out decimal result))
                    PriceTo = result;
                else
                    PriceTo = null;
                OnPropertyChanged(nameof(PriceToText));
                FilterCars();
            }
        }

        public ICommand AddCarCommand { get; }
        public ICommand EditCarCommand { get; }
        public ICommand DeleteCarCommand { get; }

        public MainViewModel()
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    _context.Categories.Load();
                    _context.Cars.Include(f => f.CarCategory).Include(f => f.Images).Load();

                    Cars = new ObservableCollection<Car>(_context.Cars.Local);
                    Categories = new ObservableCollection<CarCategory>(_context.Categories.Local);

                    if (!Categories.Any(c => c.Id == 0))
                        Categories.Insert(0, new CarCategory { Id = 0, Name = "Все" });

                    FilteredCars = new ObservableCollection<Car>(Cars);
                    SelectedCategory = Categories.FirstOrDefault();

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
                }
            }

            AddCarCommand = new RelayCommand(_ => OpenDetailsWindow(null));
            EditCarCommand = new RelayCommand(_ => OpenDetailsWindow(SelectedCar), _ => SelectedCar != null);
            DeleteCarCommand = new RelayCommand(_ => DeleteCar(), _ => SelectedCar != null);
        }

        private void OpenDetailsWindow(Car car)
        {
            Car beforeEdit = null;
            if (car != null)
                beforeEdit = CloneCar(car);

            var window = new Views.CarDetailsWindow(_context, car);
            if (window.ShowDialog() == true)
            {
                using (var transaction = _context.Database.BeginTransaction())
                {
                    try
                    {
                        _context.Cars.Include(f => f.CarCategory).Include(f => f.Images).Load();

                        Cars.Clear();
                        foreach (var f in _context.Cars.Local)
                            Cars.Add(f);

                        FilterCars();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"Ошибка при сохранении изменений: {ex.Message}");
                    }
                }
            }
        }

        private Car CloneCar(Car car)
        {
            return new Car
            {
                Id = car.Id,
                ShortName = car.ShortName,
                FullName = car.FullName,
                Description = car.Description,
                CategoryId = car.CategoryId,
                Rating = car.Rating,
                Price = car.Price,
                Quantity = car.Quantity,
                Color = car.Color,
                Size = car.Size,
                CountryOfDelivery = car.CountryOfDelivery,
                Discount = car.Discount,
                IsOutOfStock = car.IsOutOfStock,
                PurchasedCount = car.PurchasedCount,
                Manufacturer = car.Manufacturer,
                Images = car.Images?.Select(img => new CarImage
                {
                    Id = img.Id,
                    ImageData = img.ImageData != null ? (byte[])img.ImageData.Clone() : null
                }).ToList()
            };
        }

        public void FilterCars()
        {
            IQueryable<Car> query = _context.Cars.Include(f => f.CarCategory).Include(f => f.Images);

            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                var lowerSearch = SearchText.ToLower();
                query = query.Where(f => f.ShortName != null && f.ShortName.ToLower().Contains(lowerSearch));
            }

            if (SelectedCategory != null && SelectedCategory.Id != 0)
                query = query.Where(f => f.CategoryId == SelectedCategory.Id);

            if (PriceFrom.HasValue)
                query = query.Where(f => f.Price >= PriceFrom.Value);

            if (PriceTo.HasValue)
                query = query.Where(f => f.Price <= PriceTo.Value);

            FilteredCars = new ObservableCollection<Car>(query.ToList());
        }

        private void DeleteCar()
        {
            if (SelectedCar == null) return;

            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    var carToDelete = _context.Cars.Include(f => f.Images).FirstOrDefault(f => f.Id == SelectedCar.Id);
                    if (carToDelete != null)
                    {
                        foreach (var img in carToDelete.Images.ToList())
                            _context.CarImages.Remove(img);

                        _context.Cars.Remove(carToDelete);
                        _context.SaveChanges();

                        Cars.Remove(SelectedCar);
                        FilterCars();
                    }
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show($"Ошибка при удалении: {ex.Message}");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}