﻿using System.Windows;

namespace CarShopWPF
{
    public partial class App : Application
    {
    }
}
