﻿using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using CarShopWPF.Models;
using CarShopWPF.ViewModels;
using CarShopWPF.Views;

namespace lab4_7.Views
{
    public partial class MainWindow : Window
    {
        private MainViewModel _viewModel;

        public MainWindow()
        {
            InitializeComponent();
            try
            {
                string cursorUri = "pack://application:,,,/resourсes/Cursors/Arrow.ani";
                var resourceInfo = Application.GetResourceStream(new Uri(cursorUri));

                if (resourceInfo != null && resourceInfo.Stream != null)
                {
                    this.Cursor = new Cursor(resourceInfo.Stream);
                }
                else
                {
                    this.Cursor = Cursors.Arrow;
                    MessageBox.Show($"Курсор не найден по пути: {cursorUri}");
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Arrow;
                MessageBox.Show($"Ошибка при установке курсора: {ex.Message}");
            }

            _viewModel = new MainViewModel();
            DataContext = _viewModel;
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedCar = (sender as DataGrid)?.SelectedItem as Car;
            if (selectedCar != null && _viewModel != null)
            {
                _viewModel.SelectedCar = selectedCar;
            }
        }
        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            var settingsWindow = new UserSettingsWindow();
            settingsWindow.Owner = this;
            settingsWindow.ShowDialog();
        }

        private void ChangeLanguage_Click(object sender, RoutedEventArgs e)
        {
            var currentDict = Application.Current.Resources.MergedDictionaries[0];
            string currentLang = currentDict.Source.ToString();

            ResourceDictionary newDict = new ResourceDictionary();
            if (currentLang.Contains("Strings.ru.xaml"))
            {
                newDict.Source = new Uri("/lab4_7;component/Resources/Strings.en.xaml", UriKind.Relative);
            }
            else
            {
                newDict.Source = new Uri("/lab4_7;component/Resources/Strings.ru.xaml", UriKind.Relative);
            }

            Application.Current.Resources.MergedDictionaries[0] = newDict;
        }

        public void UpdateDataGridHeaders()
        {
            CarsGrid.Columns[0].Header = TryFindResource("ShortName") ?? "Краткое название";
            CarsGrid.Columns[1].Header = TryFindResource("CarCategory") ?? "Категория";
            CarsGrid.Columns[2].Header = TryFindResource("Price") ?? "Цена";
            CarsGrid.Columns[3].Header = TryFindResource("Horsepower") ?? "Лош. силы";
            CarsGrid.Columns[4].Header = TryFindResource("Have") ?? "В наличии";
            CarsGrid.Columns[5].Header = TryFindResource("Photo") ?? "Изображение";
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            var roleWindow = new RoleSelectionWindow();
            Application.Current.MainWindow = roleWindow;
            roleWindow.Show();
            this.Close();
        }

    }
}


