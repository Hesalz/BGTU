﻿using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using CarShopWPF.Models;
using lab4_7.Models;

namespace CarShopWPF.Views
{
    public partial class CarDetailsWindow : Window
    {
        private CarContext _context = new CarContext();
        private Car _car;
        private BitmapImage _selectedImage;
        private byte[] _selectedImageData;
        private CarImage _currentImage;
        private bool _isNew = false;
        private bool _previewMouseDownHandled = false;
        private bool _mouseDownHandled = false;
        private bool _gotFocusHandled = false;


        public CarDetailsWindow(CarContext context, Car car)
        {
            InitializeComponent();
            _context = context;
            try
            {
                string cursorUri = "pack://application:,,,/resourсes/Cursors/Arrow.ani";
                var resourceInfo = Application.GetResourceStream(new Uri(cursorUri));

                if (resourceInfo != null && resourceInfo.Stream != null)
                {
                    this.Cursor = new Cursor(resourceInfo.Stream);
                }
                else
                {
                    this.Cursor = Cursors.Arrow;
                    MessageBox.Show($"Курсор не найден по пути: {cursorUri}");
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Arrow;
                MessageBox.Show($"Ошибка при установке курсора: {ex.Message}");
            }
            CategoryBox.ItemsSource = _context.Categories.ToList();

            if (car == null)
            {
                _car = new Car();
                _isNew = true;
                Title = "Добавить автомобиль";
            }
            else
            {
                _car = _context.Cars.Include("Images").FirstOrDefault(f => f.Id == car.Id);
                Title = "Редактировать автомобиль";
            }

            LoadData();
        }

        public string FullName
        {
            get;
            set;
        }

        private void LoadData()
        {
            ShortNameBox.Text = _car.ShortName;
            FullName = _car.FullName;
            DescriptionBox.Text = _car.Description;
            CategoryBox.SelectedItem = _context.Categories.FirstOrDefault(c => c.Id == _car.CategoryId);
            PriceBox.Text = _car.Price.ToString();
            QuantityBox.Text = _car.Quantity.ToString();
            OutOfStockCheck.IsChecked = _car.IsOutOfStock;

            _currentImage = _car.Images?.FirstOrDefault();
            if (_currentImage != null && _currentImage.ImageData != null)
            {
                _selectedImageData = _currentImage.ImageData;
                _selectedImage = ImageConverter.ByteToImage(_currentImage.ImageData);
                CarImage.Source = _selectedImage;
                NoImageText.Visibility = Visibility.Collapsed;
            }
            else
            {
                CarImage.Source = null;
                NoImageText.Visibility = Visibility.Visible;
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ShortNameBox.Text) || CategoryBox.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, заполните обязательные поля.");
                return;
            }

            if (!decimal.TryParse(PriceBox.Text, out decimal price))
            {
                MessageBox.Show("Введите корректную цену.");
                return;
            }

            if (!int.TryParse(QuantityBox.Text, out int quantity))
            {
                MessageBox.Show("Введите корректное количество лошадиных сил.");
                return;
            }

            _car.ShortName = ShortNameBox.Text;
            _car.FullName = FullName;
            _car.Description = DescriptionBox.Text;
            _car.CategoryId = ((CarCategory)CategoryBox.SelectedItem).Id;
            _car.Price = price;
            _car.Quantity = quantity;
            _car.IsOutOfStock = OutOfStockCheck.IsChecked == true;

            if (_currentImage != null)
            {
                _context.CarImages.Remove(_currentImage);
                _car.Images.Remove(_currentImage);
                _currentImage = null;
            }

            if (_selectedImageData != null)
            {
                var newImage = new CarImage { ImageData = _selectedImageData, Car = _car };
                _car.Images.Add(newImage);
                _context.CarImages.Add(newImage);
            }

            if (_isNew)
            {
                _context.Cars.Add(_car);
            }

            _context.SaveChanges();
            DialogResult = true;
            Close();
        }

        private void LoadImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp"
            };
            if (dialog.ShowDialog() == true)
            {
                _selectedImage = new BitmapImage(new Uri(dialog.FileName));
                CarImage.Source = _selectedImage;
                _selectedImageData = ImageConverter.ImageToByte(_selectedImage);
                NoImageText.Visibility = Visibility.Collapsed;
            }
        }

        private void ClearImageCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            CarImage.Source = null;
            _selectedImage = null;
            _selectedImageData = null;
            NoImageText.Visibility = Visibility.Visible;
        }

        private void ClearImageCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = _selectedImageData != null;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }

    public class ContainsMinusConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var str = value as string;
            return !string.IsNullOrEmpty(str) && str.Contains("-");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
