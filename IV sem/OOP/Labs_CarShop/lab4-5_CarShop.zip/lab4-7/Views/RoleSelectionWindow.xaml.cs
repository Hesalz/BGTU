﻿using System.Windows;
using System.Windows.Input;
using CarShopWPF.Views;
using lab4_7.Views;

namespace CarShopWPF.Views
{
    public partial class RoleSelectionWindow : Window
    {
        public RoleSelectionWindow()
        {
            InitializeComponent();
            try
            {
                string cursorUri = "pack://application:,,,/resourсes/Cursors/Arrow.ani";
                var resourceInfo = Application.GetResourceStream(new Uri(cursorUri));

                if (resourceInfo != null && resourceInfo.Stream != null)
                {
                    this.Cursor = new Cursor(resourceInfo.Stream);
                }
                else
                {
                    this.Cursor = Cursors.Arrow;
                    MessageBox.Show($"Курсор не найден по пути: {cursorUri}");
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Arrow;
                MessageBox.Show($"Ошибка при установке курсора: {ex.Message}");
            }
        }

        private void AdminButton_Click(object sender, RoutedEventArgs e)
        {
            var adminWindow = new MainWindow();
            adminWindow.Show();
            Close();
        }

        private void UserButton_Click(object sender, RoutedEventArgs e)
        {
            var catalogWindow = new CatalogWindow();
            catalogWindow.Show();
            Close();
        }
    }
}
