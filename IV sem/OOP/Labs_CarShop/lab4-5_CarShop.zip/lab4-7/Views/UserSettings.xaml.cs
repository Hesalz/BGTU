﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using CarShopWPF.Views;
using lab4_7.Views;

namespace CarShopWPF.Views
{
    public partial class UserSettingsWindow : Window
    {
        public UserSettingsWindow()
        {
            InitializeComponent();
            SetCurrentLanguageCombo();
            try
            {
                string cursorUri = "pack://application:,,,/resourсes/Cursors/Arrow.ani";
                var resourceInfo = Application.GetResourceStream(new Uri(cursorUri));

                if (resourceInfo != null && resourceInfo.Stream != null)
                {
                    this.Cursor = new Cursor(resourceInfo.Stream);
                }
                else
                {
                    this.Cursor = Cursors.Arrow;
                    MessageBox.Show($"Курсор не найден по пути: {cursorUri}");
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Arrow;
                MessageBox.Show($"Ошибка при установке курсора: {ex.Message}");
            }
        }

        private void LanguageCombo_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            var selectedItem = LanguageCombo.SelectedItem as ComboBoxItem;
            var selected = selectedItem?.Content as string;

            if (selected == "Русский")
                SwitchLanguage("ru-RU");
            else if (selected == "English")
                SwitchLanguage("en-US");
        }

        private void SetCurrentLanguageCombo()
        {
            var langDict = Application.Current.Resources.MergedDictionaries
                .FirstOrDefault(d => d.Source != null && d.Source.OriginalString.Contains("/resourсes/Strings."));

            if (langDict != null)
            {
                if (langDict.Source.OriginalString.Contains("ru"))
                    LanguageCombo.SelectedIndex = 0;
                else
                    LanguageCombo.SelectedIndex = 1;
            }
            else
            {
                LanguageCombo.SelectedIndex = 0;
            }
        }

        private void SwitchLanguage(string culture)
        {
            try
            {
                string lang = culture.StartsWith("ru") ? "ru" : "en";
                string path = $"/resourсes/Strings.{lang}.xaml";

                var resourceDict = Application.LoadComponent(new Uri(path, UriKind.Relative)) as ResourceDictionary;

                if (resourceDict != null)
                {
                    var oldDict = Application.Current.Resources.MergedDictionaries
                        .FirstOrDefault(d => d.Source != null && d.Source.OriginalString.Contains("/resourсes/Strings."));
                    if (oldDict != null)
                        Application.Current.Resources.MergedDictionaries.Remove(oldDict);

                    Application.Current.Resources.MergedDictionaries.Add(resourceDict);
                }
                else
                {
                    MessageBox.Show("Файл локализации не найден или пуст.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при смене языка: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            foreach (Window window in Application.Current.Windows)
            {
                if (window.DataContext != null)
                {
                    var old = window.DataContext;
                    window.DataContext = null;
                    window.DataContext = old;
                }
            }
            if (this.Owner is CatalogWindow catalog)
                catalog.UpdateDataGridHeaders();
            if (this.Owner is MainWindow catalog2)
                catalog2.UpdateDataGridHeaders();
            Close();
        }
    }
}
