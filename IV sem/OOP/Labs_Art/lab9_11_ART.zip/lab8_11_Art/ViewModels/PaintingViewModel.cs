﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using PaintingSalesPlatform.DAL.Entities;
using PaintingSalesPlatform.Repositories;

namespace PaintingSalesPlatform.Models
{
    public class PaintingViewModel : INotifyPropertyChanged
    {
        private Painting painting;
        private readonly IUnitOfWork unitOfWork;

        public PaintingViewModel(Painting painting, IUnitOfWork unitOfWork)
        {
            this.painting = painting ?? throw new ArgumentNullException(nameof(painting));
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }

        public int PaintingId => painting.PaintingId;

        public string Title
        {
            get => painting.Title;
            set
            {
                if (painting.Title != value)
                {
                    painting.Title = value;
                    OnPropertyChanged();
                }
            }
        }

        public decimal Price
        {
            get => painting.Price;
            set
            {
                if (painting.Price != value)
                {
                    painting.Price = value;
                    OnPropertyChanged();
                }
            }
        }

        public int ArtistId
        {
            get => painting.ArtistId;
            set
            {
                if (painting.ArtistId != value)
                {
                    painting.ArtistId = value;
                    _ = UpdateArtistAsync(value);
                    OnPropertyChanged();
                }
            }
        }

        private async Task UpdateArtistAsync(int artistId)
        {
            try
            {
                painting.Artist = await unitOfWork.Artists.GetByIdAsync(artistId);
                OnPropertyChanged(nameof(ArtistName));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Ошибка при загрузке художника");
            }
        }

        public int CategoryId
        {
            get => painting.CategoryId;
            set
            {
                if (painting.CategoryId != value)
                {
                    painting.CategoryId = value;
                    _ = UpdateCategoryAsync(value);
                    OnPropertyChanged();
                }
            }
        }

        private async Task UpdateCategoryAsync(int categoryId)
        {
            try
            {
                painting.Category = await unitOfWork.Categories.GetByIdAsync(categoryId);
                OnPropertyChanged(nameof(CategoryName));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Ошибка при загрузке категории");
            }
        }

        public string ArtistName => painting.Artist?.Name;

        public string CategoryName => painting.Category?.Name;

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }
    }
}
