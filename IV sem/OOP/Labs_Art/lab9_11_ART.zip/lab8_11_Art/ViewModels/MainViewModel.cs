﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using PaintingSalesPlatform.DAL.Entities;
using PaintingSalesPlatform.Models;
using PaintingSalesPlatform.Repositories;

namespace PaintingSalesPlatform.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly IUnitOfWork unitOfWork;

        private ObservableCollection<PaintingViewModel> paintings;
        public ICollectionView PaintingsView { get; private set; }

        private string searchText;
        private string selectedSortOption;
        private readonly Category allCategory = new Category { CategoryId = -1, Name = "Все" };

        private PaintingViewModel selectedPainting;
        public PaintingViewModel SelectedPainting
        {
            get => selectedPainting;
            set
            {
                if (selectedPainting != value)
                {
                    selectedPainting = value;
                    OnPropertyChanged(nameof(SelectedPainting));
                }
            }
        }

        public MainViewModel() : this(new UnitOfWork())
        {
        }

        public MainViewModel(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

            Artists = new ObservableCollection<Artist>();
            Categories = new ObservableCollection<Category>();

            paintings = new ObservableCollection<PaintingViewModel>();
            PaintingsView = CollectionViewSource.GetDefaultView(paintings);
            PaintingsView.Filter = FilterPaintings;

            SortOptions = new[] { "Title", "Price", "Artist", "Category" };
            SelectedSortOption = SortOptions[0];

            FilterCommand = new RelayCommand(_ => ApplyFilterAndSort());
            ClearFilterCommand = new RelayCommand(_ => ClearFilter());

            AddCommand = new RelayCommand(async _ => await AddPaintingAsync(), _ => CanAddPainting());
            UpdateCommand = new RelayCommand(async _ => await UpdatePaintingAsync(), _ => CanUpdatePainting());
            DeleteCommand = new RelayCommand(async _ => await DeletePaintingAsync(), _ => CanDeletePainting());

            SelectedCategory = allCategory;
        }

        public async Task InitializeAsync()
        {
            await LoadLookupsAsync();
            await LoadDataAsync();
        }

        public string[] SortOptions { get; }

        public string SelectedSortOption
        {
            get => selectedSortOption;
            set
            {
                if (selectedSortOption != value)
                {
                    selectedSortOption = value;
                    OnPropertyChanged(nameof(SelectedSortOption));
                    ApplyFilterAndSort();
                }
            }
        }

        public string SearchText
        {
            get => searchText;
            set
            {
                if (searchText != value)
                {
                    searchText = value;
                    OnPropertyChanged(nameof(SearchText));
                    ApplyFilterAndSort();
                }
            }
        }

        public ICommand FilterCommand { get; }
        public ICommand ClearFilterCommand { get; }

        public ICommand AddCommand { get; }
        public ICommand UpdateCommand { get; }
        public ICommand DeleteCommand { get; }
        private Category selectedCategory;

        public Category SelectedCategory
        {
            get => selectedCategory;
            set
            {
                if (selectedCategory != value)
                {
                    selectedCategory = value;
                    OnPropertyChanged(nameof(SelectedCategory));
                    ApplyFilterAndSort();
                }
            }
        }

        public List<Category> CategoryOptions
        {
            get
            {
                var list = new List<Category> { allCategory };
                list.AddRange(Categories);
                return list;
            }
        }


        public async Task LoadDataAsync()
        {
            var paintingsList = await unitOfWork.Paintings.GetAsync(includeProperties: "Artist,Category");

            paintings.Clear();
            foreach (var p in paintingsList)
            {
                paintings.Add(new PaintingViewModel(p, unitOfWork));
            }

            PaintingsView.Refresh();
            ApplyFilterAndSort();
        }

        private bool FilterPaintings(object obj)
        {
            if (obj is PaintingViewModel pvm)
            {
                var lowerSearch = SearchText?.ToLower() ?? string.Empty;

                bool matchesText = string.IsNullOrWhiteSpace(SearchText) ||
                                   (pvm.Title?.ToLower().Contains(lowerSearch) == true) ||
                                   (pvm.ArtistName?.ToLower().Contains(lowerSearch) == true) ||
                                   (pvm.CategoryName?.ToLower().Contains(lowerSearch) == true);

                bool matchesCategory = SelectedCategory == null || SelectedCategory.CategoryId == -1 ||
                        string.Equals(pvm.CategoryName, SelectedCategory.Name, StringComparison.OrdinalIgnoreCase);


                return matchesText && matchesCategory;
            }
            return false;
        }


        private void ApplyFilterAndSort()
        {
            if (PaintingsView == null) return;

            PaintingsView.Refresh();

            PaintingsView.SortDescriptions.Clear();

            switch (SelectedSortOption)
            {
                case "Title":
                    PaintingsView.SortDescriptions.Add(new SortDescription("Title", ListSortDirection.Ascending));
                    break;
                case "Price":
                    PaintingsView.SortDescriptions.Add(new SortDescription("Price", ListSortDirection.Ascending));
                    break;
                case "Artist":
                    PaintingsView.SortDescriptions.Add(new SortDescription("ArtistName", ListSortDirection.Ascending));
                    break;
                case "Category":
                    PaintingsView.SortDescriptions.Add(new SortDescription("CategoryName", ListSortDirection.Ascending));
                    break;
            }
        }

        public ObservableCollection<Artist> Artists { get; set; }
        public ObservableCollection<Category> Categories { get; set; }

        public async Task LoadLookupsAsync()
        {
            var artists = await unitOfWork.Artists.GetAsync();
            Artists.Clear();
            foreach (var artist in artists)
            {
                Artists.Add(artist);
            }

            var categories = await unitOfWork.Categories.GetAsync();
            Categories.Clear();
            foreach (var category in categories)
            {
                Categories.Add(category);
            }

            MessageBox.Show($"Загружено: {Artists.Count} художников, {Categories.Count} категорий");

            OnPropertyChanged(nameof(Artists));
            OnPropertyChanged(nameof(Categories));
        }

        private void ClearFilter()
        {
            SearchText = string.Empty;
            SelectedCategory = allCategory;
        }

        private bool CanAddPainting()
        {
            return Artists.Any() && Categories.Any();
        }

        private bool CanUpdatePainting()
        {
            return SelectedPainting != null;
        }

        private bool CanDeletePainting()
        {
            return SelectedPainting != null;
        }

        public async Task AddPaintingAsync()
        {
            if (!Artists.Any() || !Categories.Any())
            {
                MessageBox.Show("Невозможно добавить картину: отсутствуют художники или категории.");
                return;
            }

            var newPainting = new Painting
            {
                Title = "Новая Картина",
                Price = 1000m,
                ArtistId = Artists.First().ArtistId,
                CategoryId = Categories.First().CategoryId
            };

            await unitOfWork.Paintings.InsertAsync(newPainting);
            await unitOfWork.SaveAsync();

            var paintingWithIncludes = await unitOfWork.Paintings.GetAsync(
                filter: p => p.PaintingId == newPainting.PaintingId,
                includeProperties: "Artist,Category");

            var paintingVm = new PaintingViewModel(paintingWithIncludes.First(), unitOfWork);
            paintings.Add(paintingVm);
            PaintingsView.Refresh();

            SelectedPainting = paintingVm;
        }

        public async Task UpdatePaintingAsync()
        {
            if (SelectedPainting == null)
                return;

            SelectedPainting.Title += " (обновлено)";
            SelectedPainting.Price += 100;

            var paintingEntity = await unitOfWork.Paintings.GetByIdAsync(SelectedPainting.PaintingId);
            if (paintingEntity == null)
                return;

            paintingEntity.Title = SelectedPainting.Title;
            paintingEntity.Price = SelectedPainting.Price;

            unitOfWork.Paintings.Update(paintingEntity);
            await unitOfWork.SaveAsync();

            PaintingsView.Refresh();
        }

        public async Task DeletePaintingAsync()
        {
            if (SelectedPainting == null)
                return;

            var paintingEntity = await unitOfWork.Paintings.GetByIdAsync(SelectedPainting.PaintingId);
            if (paintingEntity == null)
                return;

            unitOfWork.Paintings.Delete(paintingEntity);
            await unitOfWork.SaveAsync();

            paintings.Remove(SelectedPainting);
            PaintingsView.Refresh();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }
    }
}
