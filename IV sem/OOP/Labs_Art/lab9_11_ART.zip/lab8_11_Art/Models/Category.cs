﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PaintingSalesPlatform.DAL.Entities
{
    public class Category
    {
        public int CategoryId { get; set; }

        [Required]
        public string Name { get; set; }

        public virtual ICollection<Painting> Paintings { get; set; }
    }
}
