﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Windows;
using PaintingSalesPlatform.DAL.Entities;

namespace PaintingSalesPlatform.DAL
{
    public class PaintingContext : DbContext
    {
        public PaintingContext() : base("name=PaintingContext")
        {
            Database.SetInitializer(new CreateDatabaseIfNotExists<PaintingContext>());
        }

        public DbSet<Artist> Artists { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Painting> Paintings { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Artist>()
                .HasMany(a => a.Paintings)
                .WithRequired(p => p.Artist)
                .HasForeignKey(p => p.ArtistId);

            modelBuilder.Entity<Category>()
                .HasMany(c => c.Paintings)
                .WithRequired(p => p.Category)
                .HasForeignKey(p => p.CategoryId);

            base.OnModelCreating(modelBuilder);
        }

        public void SeedIfEmpty()
        {
            try
            {
                if (!Categories.Any() && !Artists.Any() && !Paintings.Any())
                {
                    var categories = new List<Category>
            {
                new Category { Name = "Пейзаж" },
                new Category { Name = "Портрет" },
                new Category { Name = "Абстракция" },
                new Category { Name = "Натюрморт" }
            };

                var artists = new List<Artist>
                {
                    new Artist { Name = "Иван Иванов" },
                    new Artist { Name = "Мария Петрова" },
                    new Artist { Name = "Сергей Козлов" },
                    new Artist { Name = "Анна Смирнова" }
                };

                    Categories.AddRange(categories);
                    Artists.AddRange(artists);
                    SaveChanges();

                    var paintings = new List<Painting>
                    {
                        new Painting
                        {
                            Title = "Зимний вечер",
                            Price = 1500m,
                            ArtistId = artists[0].ArtistId,
                            CategoryId = categories[0].CategoryId
                        },
                        new Painting
                        {
                            Title = "Портрет девушки",
                            Price = 2300m,
                            ArtistId = artists[1].ArtistId,
                            CategoryId = categories[1].CategoryId
                        },
                        new Painting
                        {
                            Title = "Абстракция времени",
                            Price = 1800m,
                            ArtistId = artists[2].ArtistId,
                            CategoryId = categories[2].CategoryId
                        },
                        new Painting
                        {
                            Title = "Фрукты и цветы",
                            Price = 1200m,
                            ArtistId = artists[0].ArtistId,
                            CategoryId = categories[3].CategoryId
                        },
                        new Painting
                        {
                            Title = "Городской пейзаж",
                            Price = 2000m,
                            ArtistId = artists[3].ArtistId,
                            CategoryId = categories[0].CategoryId
                        },
                        new Painting
                        {
                            Title = "Морской бриз",
                            Price = 1700m,
                            ArtistId = artists[1].ArtistId,
                            CategoryId = categories[2].CategoryId
                        },
                        new Painting
                        {
                            Title = "Натюрморт с книгами",
                            Price = 1600m,
                            ArtistId = artists[2].ArtistId,
                            CategoryId = categories[3].CategoryId
                        },
                        new Painting
                        {
                            Title = "Весенний сад",
                            Price = 1900m,
                            ArtistId = artists[0].ArtistId,
                            CategoryId = categories[2].CategoryId
                        },
                        new Painting
                        {
                            Title = "Портрет старика",
                            Price = 2500m,
                            ArtistId = artists[3].ArtistId,
                            CategoryId = categories[1].CategoryId
                        },
                        new Painting
                        {
                            Title = "Космическая одиссея",
                            Price = 3000m,
                            ArtistId = artists[2].ArtistId,
                            CategoryId = categories[1].CategoryId
                        },
                        new Painting
                        {
                            Title = "Осенний лес",
                            Price = 1400m,
                            ArtistId = artists[1].ArtistId,
                            CategoryId = categories[0].CategoryId
                        },
                        new Painting
                        {
                            Title = "Музыкальная тема",
                            Price = 2200m,
                            ArtistId = artists[0].ArtistId,
                            CategoryId = categories[1].CategoryId
                        },
                        new Painting
                        {
                            Title = "Танец света",
                            Price = 2100m,
                            ArtistId = artists[3].ArtistId,
                            CategoryId = categories[2].CategoryId
                        }
                    };

                    Paintings.AddRange(paintings);
                    SaveChanges();

                    MessageBox.Show("База успешно инициализирована начальными данными.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при инициализации базы: " + ex.Message);
            }
        }

    }
}
