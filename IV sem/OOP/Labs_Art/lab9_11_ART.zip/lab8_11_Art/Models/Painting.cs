﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PaintingSalesPlatform.DAL.Entities
{
    public class Painting
    {
        public int PaintingId { get; set; }
        [Required]
        public string Title { get; set; }
        public decimal Price { get; set; }
        public int ArtistId { get; set; }
        public int CategoryId { get; set; }
        public virtual Artist Artist { get; set; }
        public virtual Category Category { get; set; }
    }
}
