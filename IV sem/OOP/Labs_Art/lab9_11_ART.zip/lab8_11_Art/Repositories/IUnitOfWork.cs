﻿using System;
using System.Threading.Tasks;
using PaintingSalesPlatform.DAL.Entities;
using PaintingSalesPlatform.Models;

namespace PaintingSalesPlatform.Repositories
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<Artist> Artists { get; }
        IRepository<Category> Categories { get; }
        IRepository<Painting> Paintings { get; }

        Task SaveAsync();
    }
}
