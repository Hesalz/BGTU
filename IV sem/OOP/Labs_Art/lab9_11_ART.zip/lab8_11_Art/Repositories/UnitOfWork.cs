﻿using System;
using System.Threading.Tasks;
using PaintingSalesPlatform.DAL;
using PaintingSalesPlatform.DAL.Entities;
using PaintingSalesPlatform.Models;

namespace PaintingSalesPlatform.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private PaintingContext context = new PaintingContext();

        private IRepository<Artist> artistRepository;
        private IRepository<Category> categoryRepository;
        private IRepository<Painting> paintingRepository;

        public UnitOfWork()
        {
            context.SeedIfEmpty(); 
        }


        public IRepository<Artist> Artists
        {
            get
            {
                if (artistRepository == null)
                    artistRepository = new GenericRepository<Artist>(context);
                return artistRepository;
            }
        }

        public IRepository<Category> Categories
        {
            get
            {
                if (categoryRepository == null)
                    categoryRepository = new GenericRepository<Category>(context);
                return categoryRepository;
            }
        }

        public IRepository<Painting> Paintings
        {
            get
            {
                if (paintingRepository == null)
                    paintingRepository = new GenericRepository<Painting>(context);
                return paintingRepository;
            }
        }

        public async Task SaveAsync()
        {
            await context.SaveChangesAsync();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
