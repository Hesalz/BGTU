﻿using System.Windows;
using PaintingSalesPlatform.DAL;
using PaintingSalesPlatform.ViewModels;
namespace PaintingSalesPlatform.Views
{
    public partial class MainWindow : Window
    {
        public MainViewModel ViewModel => DataContext as MainViewModel;

        public MainWindow()
        {
            InitializeComponent();
            InitializeAsync();
            DataContext = new MainViewModel();
        }

        private async void InitializeAsync()
        {
            var vm = new MainViewModel();
            await vm.InitializeAsync(); 
            DataContext = vm;
        }
    }

}
