﻿using System.Windows;

namespace PictureShopADO
{
    public partial class AddEditArtistWindow : Window
    {
        public string ArtistName { get; private set; }

        public AddEditArtistWindow(int artistId = 0, string name = "")
        {
            InitializeComponent();
            if (!string.IsNullOrEmpty(name))
                txtName.Text = name;
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите имя художника!");
                return;
            }
            ArtistName = txtName.Text;
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
