﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace PictureShopADO
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            DatabaseHelper.EnsureDatabaseExists();
            DataAccess.EnsureDatabaseAndUser();

            LoadArtists();
        }

        private void LoadArtists()
        {
            string sql = "SELECT Id, Name FROM Artists";
            DataTable dt = DataAccess.ExecuteQuery(sql);
            dgArtists.ItemsSource = dt.DefaultView;
            dgPaintings.ItemsSource = null;
        }

        private void LoadPaintings(int artistId)
        {
            string sql = "SELECT Id, Title, Price, Technique, Image FROM Paintings WHERE ArtistId = @ArtistId";
            var parameters = new SqlParameter[]
            {
                new SqlParameter("@ArtistId", artistId)
            };
            DataTable dt = DataAccess.ExecuteQuery(sql, parameters);
            dgPaintings.ItemsSource = dt.DefaultView;
        }

        private void DgArtists_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (dgArtists.SelectedItem is DataRowView drv)
            {
                int artistId = (int)drv["Id"];
                LoadPaintings(artistId);
            }
            else
            {
                dgPaintings.ItemsSource = null;
            }
        }

        private void AddArtist_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddEditArtistWindow();
            if (window.ShowDialog() == true)
            {
                using (SqlConnection conn = new SqlConnection(DataAccess.DatabaseConnectionString))
                {
                    conn.Open();
                    using (SqlTransaction tran = conn.BeginTransaction())
                    {
                        try
                        {
                            using (SqlCommand cmd = new SqlCommand("usp_AddArtist", conn, tran))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add(new SqlParameter("@Name", window.ArtistName));
                                cmd.ExecuteNonQuery();
                            }
                            tran.Commit();
                            LoadArtists();
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            MessageBox.Show("Ошибка при добавлении художника: " + ex.Message);
                        }
                    }
                }
            }
        }

        private void EditArtist_Click(object sender, RoutedEventArgs e)
        {
            if (dgArtists.SelectedItem is DataRowView drv)
            {
                int artistId = (int)drv["Id"];
                string name = (string)drv["Name"];

                var window = new AddEditArtistWindow(artistId, name);
                if (window.ShowDialog() == true)
                {
                    using (SqlConnection conn = new SqlConnection(DataAccess.DatabaseConnectionString))
                    {
                        conn.Open();
                        using (SqlTransaction tran = conn.BeginTransaction())
                        {
                            try
                            {
                                string sql = "UPDATE Artists SET Name = @Name WHERE Id = @Id";
                                using (SqlCommand cmd = new SqlCommand(sql, conn, tran))
                                {
                                    cmd.Parameters.Add(new SqlParameter("@Name", window.ArtistName));
                                    cmd.Parameters.Add(new SqlParameter("@Id", artistId));
                                    cmd.ExecuteNonQuery();
                                }
                                tran.Commit();
                                LoadArtists();
                            }
                            catch (Exception ex)
                            {
                                tran.Rollback();
                                MessageBox.Show("Ошибка при редактировании художника: " + ex.Message);
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите художника для редактирования.");
            }
        }

        private void DeleteArtist_Click(object sender, RoutedEventArgs e)
        {
            if (dgArtists.SelectedItem is DataRowView drv)
            {
                int artistId = (int)drv["Id"];
                if (MessageBox.Show("Удалить выбранного художника?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    using (SqlConnection conn = new SqlConnection(DataAccess.DatabaseConnectionString))
                    {
                        conn.Open();
                        using (SqlTransaction tran = conn.BeginTransaction())
                        {
                            try
                            {
                                string sql = "DELETE FROM Artists WHERE Id = @Id";
                                using (SqlCommand cmd = new SqlCommand(sql, conn, tran))
                                {
                                    cmd.Parameters.Add(new SqlParameter("@Id", artistId));
                                    cmd.ExecuteNonQuery();
                                }
                                tran.Commit();
                                LoadArtists();
                            }
                            catch (Exception ex)
                            {
                                tran.Rollback();
                                MessageBox.Show("Ошибка при удалении художника: " + ex.Message);
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите художника для удаления.");
            }
        }

        private void AddPainting_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddEditPaintingWindow();
            if (window.ShowDialog() == true)
            {
                using (SqlConnection conn = new SqlConnection(DataAccess.DatabaseConnectionString))
                {
                    conn.Open();
                    using (SqlTransaction tran = conn.BeginTransaction())
                    {
                        try
                        {
                            using (SqlCommand cmd = new SqlCommand("usp_AddPainting", conn, tran))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add(new SqlParameter("@Title", window.PaintingTitle));
                                cmd.Parameters.Add(new SqlParameter("@Price", window.Price));
                                cmd.Parameters.Add(new SqlParameter("@Technique", window.Technique));
                                cmd.Parameters.Add(new SqlParameter("@Image", window.ImageBytes));
                                cmd.Parameters.Add(new SqlParameter("@ArtistId", window.ArtistId));
                                cmd.ExecuteNonQuery();
                            }
                            tran.Commit();
                            if (dgArtists.SelectedItem is DataRowView drv)
                            {
                                LoadPaintings((int)drv["Id"]);
                            }
                        }
                        catch (Exception ex)
                        {
                            tran.Rollback();
                            MessageBox.Show("Ошибка при добавлении картины: " + ex.Message);
                        }
                    }
                }
            }
        }

        private void EditPainting_Click(object sender, RoutedEventArgs e)
        {
            if (dgPaintings.SelectedItem is DataRowView drvPainting && dgArtists.SelectedItem is DataRowView drvArtist)
            {
                int paintingId = (int)drvPainting["Id"];
                string title = (string)drvPainting["Title"];
                decimal price = (decimal)drvPainting["Price"];
                string technique = (string)drvPainting["Technique"];
                int artistId = (int)drvArtist["Id"];
                byte[] image = null;

                string sqlGetImage = "SELECT Image FROM Paintings WHERE Id = @Id";
                var param = new SqlParameter[] {
                    new SqlParameter("@Id", paintingId)
                };
                DataTable dt = DataAccess.ExecuteQuery(sqlGetImage, param);
                if (dt.Rows.Count > 0 && dt.Rows[0]["Image"] != DBNull.Value)
                    image = (byte[])dt.Rows[0]["Image"];

                var window = new AddEditPaintingWindow(paintingId, title, price, technique, artistId, image);
                if (window.ShowDialog() == true)
                {
                    using (SqlConnection conn = new SqlConnection(DataAccess.DatabaseConnectionString))
                    {
                        conn.Open();
                        using (SqlTransaction tran = conn.BeginTransaction())
                        {
                            try
                            {
                                string sql = @"UPDATE Paintings 
                                               SET Title = @Title, Price = @Price, Technique = @Technique, Image = @Image, ArtistId = @ArtistId 
                                               WHERE Id = @Id";
                                using (SqlCommand cmd = new SqlCommand(sql, conn, tran))
                                {
                                    cmd.Parameters.Add(new SqlParameter("@Title", window.PaintingTitle));
                                    cmd.Parameters.Add(new SqlParameter("@Price", window.Price));
                                    cmd.Parameters.Add(new SqlParameter("@Technique", window.Technique));
                                    cmd.Parameters.Add(new SqlParameter("@Image", window.ImageBytes));
                                    cmd.Parameters.Add(new SqlParameter("@ArtistId", window.ArtistId));
                                    cmd.Parameters.Add(new SqlParameter("@Id", paintingId));
                                    cmd.ExecuteNonQuery();
                                }
                                tran.Commit();
                                LoadPaintings(window.ArtistId);
                            }
                            catch (Exception ex)
                            {
                                tran.Rollback();
                                MessageBox.Show("Ошибка при редактировании картины: " + ex.Message);
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите картину для редактирования.");
            }
        }

        private void DeletePainting_Click(object sender, RoutedEventArgs e)
        {
            if (dgPaintings.SelectedItem is DataRowView drv)
            {
                int paintingId = (int)drv["Id"];
                if (MessageBox.Show("Удалить выбранную картину?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    using (SqlConnection conn = new SqlConnection(DataAccess.DatabaseConnectionString))
                    {
                        conn.Open();
                        using (SqlTransaction tran = conn.BeginTransaction())
                        {
                            try
                            {
                                string sql = "DELETE FROM Paintings WHERE Id = @Id";
                                using (SqlCommand cmd = new SqlCommand(sql, conn, tran))
                                {
                                    cmd.Parameters.Add(new SqlParameter("@Id", paintingId));
                                    cmd.ExecuteNonQuery();
                                }
                                tran.Commit();
                                if (dgArtists.SelectedItem is DataRowView drvArtist)
                                {
                                    LoadPaintings((int)drvArtist["Id"]);
                                }
                            }
                            catch (Exception ex)
                            {
                                tran.Rollback();
                                MessageBox.Show("Ошибка при удалении картины: " + ex.Message);
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите картину для удаления.");
            }
        }
    }
}
