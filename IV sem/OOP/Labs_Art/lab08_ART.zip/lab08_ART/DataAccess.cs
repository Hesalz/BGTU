﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace PictureShopADO
{
    public static class DataAccess
    {
        public static string MasterConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["MasterConn"].ConnectionString; }
        }
        public static string DatabaseConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["PictureShopConn"].ConnectionString; }
        }

        public static void EnsureDatabaseAndUser()
        {
            using (SqlConnection connection = new SqlConnection(MasterConnectionString))
            {
                connection.Open();

                string createDbSql = @"
IF DB_ID('PictureShop_ADO') IS NULL
BEGIN
    CREATE DATABASE PictureShop_ADO;
END
";
                using (SqlCommand cmd = new SqlCommand(createDbSql, connection))
                {
                    cmd.ExecuteNonQuery();
                }

                string createTablesSql = @"
USE PictureShop_ADO;

IF OBJECT_ID('Artists', 'U') IS NULL
BEGIN
    CREATE TABLE Artists (
        Id INT IDENTITY PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL
    );
END

IF OBJECT_ID('Paintings', 'U') IS NULL
BEGIN
    CREATE TABLE Paintings (
        Id INT IDENTITY PRIMARY KEY,
        Title NVARCHAR(100) NOT NULL,
        Price MONEY NOT NULL,
        Technique NVARCHAR(100) NOT NULL,
        Image VARBINARY(MAX) NOT NULL,
        ArtistId INT FOREIGN KEY REFERENCES Artists(Id)
    );
END

IF OBJECT_ID('PaintingLog', 'U') IS NULL
BEGIN
    CREATE TABLE PaintingLog (
        LogId INT IDENTITY PRIMARY KEY,
        PaintingId INT,
        InsertedAt DATETIME DEFAULT GETDATE()
    );
END
";
                using (SqlCommand cmd = new SqlCommand(createTablesSql, connection))
                {
                    cmd.ExecuteNonQuery();
                }

                string createTriggerSql = @"
USE PictureShop_ADO;

IF OBJECT_ID('tr_PaintingInsert_Log', 'TR') IS NULL
BEGIN
    EXEC('
    CREATE TRIGGER tr_PaintingInsert_Log
    ON Paintings
    AFTER INSERT
    AS
    BEGIN
        INSERT INTO PaintingLog (PaintingId)
        SELECT Id FROM INSERTED;
    END
    ');
END
";
                using (SqlCommand cmd = new SqlCommand(createTriggerSql, connection))
                {
                    cmd.ExecuteNonQuery();
                }

                string createProcAddArtist = @"
USE PictureShop_ADO;

IF OBJECT_ID('usp_AddArtist', 'P') IS NULL
BEGIN
    EXEC('
    CREATE PROCEDURE usp_AddArtist
        @Name NVARCHAR(100)
    AS
    BEGIN
        INSERT INTO Artists (Name) VALUES (@Name);
    END
    ');
END
";
                using (SqlCommand cmd = new SqlCommand(createProcAddArtist, connection))
                {
                    cmd.ExecuteNonQuery();
                }

                string createProcAddPainting = @"
USE PictureShop_ADO;

IF OBJECT_ID('usp_AddPainting', 'P') IS NULL
BEGIN
    EXEC('
    CREATE PROCEDURE usp_AddPainting
        @Title NVARCHAR(100),
        @Price MONEY,
        @Technique NVARCHAR(100),
        @Image VARBINARY(MAX),
        @ArtistId INT
    AS
    BEGIN
        IF @Image IS NULL
            THROW 50000, ''Image is required.'', 1;

        INSERT INTO Paintings (Title, Price, Technique, Image, ArtistId)
        VALUES (@Title, @Price, @Technique, @Image, @ArtistId);
    END
    ');
END
";
                using (SqlCommand cmd = new SqlCommand(createProcAddPainting, connection))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static DataTable ExecuteQuery(string sql, SqlParameter[] parameters = null)
        {
            using (SqlConnection conn = new SqlConnection(DatabaseConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (parameters != null)
                        cmd.Parameters.AddRange(parameters);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        public static int ExecuteNonQuery(string sql, SqlParameter[] parameters = null)
        {
            using (SqlConnection conn = new SqlConnection(DatabaseConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (parameters != null)
                        ValidateAndAddParameters(cmd, parameters);
                    conn.Open();
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        public static int ExecuteStoredProcedure(string procedureName, SqlParameter[] parameters = null)
        {
            using (SqlConnection conn = new SqlConnection(DatabaseConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(procedureName, conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (parameters != null)
                        ValidateAndAddParameters(cmd, parameters);
                    conn.Open();
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        private static void ValidateAndAddParameters(SqlCommand cmd, SqlParameter[] parameters)
        {
            foreach (SqlParameter param in parameters)
            {
                if (param.ParameterName.Equals("@Image", StringComparison.OrdinalIgnoreCase) &&
                    (param.Value == null || param.Value == DBNull.Value))
                {
                    MessageBox.Show(
                        "Параметр " + param.ParameterName + " обязателен и не может быть пустым.",
                        "Ошибка ввода данных",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    throw new ArgumentException("Параметр " + param.ParameterName + " обязателен и не может быть пустым.");
                }

                if ((param.SqlDbType == SqlDbType.VarBinary || param.SqlDbType == SqlDbType.Image) &&
                    param.Value is string)
                {
                    MessageBox.Show(
                        "Параметр " + param.ParameterName + " должен быть типа byte[], а не string.",
                        "Ошибка ввода данных",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    throw new ArgumentException("Параметр " + param.ParameterName + " должен быть типа byte[], а не string.");
                }

                cmd.Parameters.Add(param);
            }
        }
    }
}
