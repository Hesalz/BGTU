﻿using System.Data;
using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace PictureShopADO
{
    public partial class AddEditPaintingWindow : Window
    {
        public string PaintingTitle { get; private set; }
        public decimal Price { get; private set; }
        public string Technique { get; private set; }
        public int ArtistId { get; private set; }
        public byte[] ImageBytes { get; private set; }

        private bool imageWasChanged = false;

        public AddEditPaintingWindow(int paintingId = 0, string title = "", decimal price = 0, string technique = "", int artistId = 0, byte[] image = null)
        {
            InitializeComponent();
            LoadArtists();
            if (!string.IsNullOrEmpty(title)) txtTitle.Text = title;
            if (price > 0) txtPrice.Text = price.ToString();
            if (!string.IsNullOrEmpty(technique)) txtTechnique.Text = technique;
            if (artistId > 0) cmbArtists.SelectedValue = artistId;
            if (image != null)
            {
                ImageBytes = image;
                txtImagePath.Text = "[Текущее изображение]";
            }
        }

        private void LoadArtists()
        {
            string sql = "SELECT Id, Name FROM Artists";
            DataTable artists = DataAccess.ExecuteQuery(sql);
            cmbArtists.ItemsSource = artists.DefaultView;
        }

        private void ChooseImage_Click(object sender, RoutedEventArgs e)
        {
            var ofd = new OpenFileDialog { Filter = "Картинки|*.png;*.jpg;*.jpeg;*.bmp" };
            if (ofd.ShowDialog() == true)
            {
                ImageBytes = File.ReadAllBytes(ofd.FileName);
                txtImagePath.Text = System.IO.Path.GetFileName(ofd.FileName);
                imageWasChanged = true;
            }
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Введите название картины!");
                return;
            }
            if (!decimal.TryParse(txtPrice.Text, out decimal price))
            {
                MessageBox.Show("Введите корректную цену!");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtTechnique.Text))
            {
                MessageBox.Show("Введите технику!");
                return;
            }
            if (cmbArtists.SelectedValue == null)
            {
                MessageBox.Show("Выберите художника!");
                return;
            }
            if (ImageBytes == null)
            {
                MessageBox.Show("Выберите изображение!");
                return;
            }

            PaintingTitle = txtTitle.Text;
            Price = price;
            Technique = txtTechnique.Text;
            ArtistId = (int)cmbArtists.SelectedValue;
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        public bool ImageWasChanged
        {
            get { return imageWasChanged; }
        }
    }
}
