﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using OOP_Lab4_5.Classes;

namespace OOP_Lab4_5
{
    public partial class ViewAllBooks : Window
    {
        private Gallery _listOfBooks;
        private CommandManager _commandManager = new CommandManager();

        public ViewAllBooks()
        {
            InitializeComponent();
            _listOfBooks = DataTransfer.DeserializeBooks();
            tableView.ItemsSource = _listOfBooks.booksList;

            var sri = Application.GetResourceStream(new Uri("./Styles/arrow.cur", UriKind.Relative));
            var customCursor = new Cursor(sri.Stream);
            Cursor = customCursor;
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void CommandBinding_Executed_1(object sender, RoutedEventArgs e)
        {
            _listOfBooks = DataTransfer.DeserializeBooks();
            var library = new Gallery();
            string searchText = searchBox.Text.ToLower();

            foreach (var item in _listOfBooks.booksList)
            {
                string title = item.Title.ToLower();
                string pattern = @"\b" + Regex.Escape(searchText) + @"\w*";

                if (Regex.IsMatch(title, pattern, RegexOptions.IgnoreCase))
                {
                    library.booksList.Add(item);
                }
            }

            tableView.ItemsSource = library.booksList;
        }

        private void CommandBinding_Executed_2(object sender, ExecutedRoutedEventArgs e)
        {
            AddingBook book = new AddingBook();
            book.Closed += (s, args) =>
            {
                if (book._book != null && !string.IsNullOrEmpty(book._book.Title))
                {
                    var command = new AddArtCommand(_listOfBooks, book._book);
                    _commandManager.ExecuteCommand(command);
                    RefreshBookList();
                }
            };
            book.Show();
        }

        private void CommandBinding_Executed_3(object sender, RoutedEventArgs e)
        {
            var bookEdit = (Art)tableView.SelectedItem;
            if (bookEdit != null)
            {
                RedactingBook edit = new RedactingBook(bookEdit) { Owner = this };
                if (edit.ShowDialog() == false)
                {
                    bookEdit.Title = edit.bookName.Text;
                    bookEdit.Author = edit.bookAuthor.Text;
                    bookEdit.Genre = edit.genre.Text;
                    bookEdit.InStock = int.Parse(edit.in_stock.Text);
                    if (int.TryParse(edit.ratingControl.Rating.ToString(), out int ratingValue))
                    {
                        bookEdit.Rating = ratingValue;
                    }
                    bookEdit.Photo = edit.preview.Source.ToString();
                    tableView.Items.Refresh();
                    DataTransfer.SerializeBooks(_listOfBooks);
                }
            }
        }

        private void CommandBinding_Executed_4(object sender, ExecutedRoutedEventArgs e)
        {
            Art selectedBook = (Art)tableView.SelectedItem;
            if (selectedBook != null)
            {
                var command = new DeleteArtCommand(_listOfBooks, selectedBook);
                _commandManager.ExecuteCommand(command);
                RefreshBookList();
                MessageBox.Show("Книга удалена.", "Успешно!", MessageBoxButton.OK);
            }
        }

        private void CommandBinding_Executed_5(object sender, RoutedEventArgs e)
        {
            RefreshBookList();
        }

        private void CommandBinding_Executed_6(object sender, RoutedEventArgs e)
        {
            _listOfBooks = DataTransfer.DeserializeBooks();
            var library = new Gallery();
            foreach (var item in _listOfBooks.booksList)
                if (item.Genre == comboBoxFilterSelect.Text)
                    library.booksList.Add(item);

            tableView.ItemsSource = library.booksList;
        }

        private void UndoCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            _commandManager.Undo();
            RefreshBookList();
        }

        private void RedoCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            _commandManager.Redo();
            RefreshBookList();
        }

        private void RefreshBookList()
        {
            _listOfBooks = DataTransfer.DeserializeBooks();
            tableView.ItemsSource = _listOfBooks.booksList;
            tableView.Items.Refresh();
        }

        private void tableView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (tableView.SelectedItem != null)
            {
                Art selectedBook = (Art)tableView.SelectedItem;
                BookDetailsWindow bookDetailsWindow = new BookDetailsWindow(selectedBook)
                {
                    Owner = this
                };
                bookDetailsWindow.Show();
            }
        }
    }
}