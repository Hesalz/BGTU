﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace OOP_Lab4_5
{
    public partial class RatingControl : UserControl, INotifyPropertyChanged
    {
        public RatingControl()
        {
            InitializeComponent();
            UpdateStars();
        }

        // DependencyProperty для Rating
        public static readonly DependencyProperty RatingProperty =
            DependencyProperty.Register(
                nameof(Rating),
                typeof(int),
                typeof(RatingControl),
                new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnRatingChanged, CoerceRating),
                ValidateRating);

        public int Rating
        {
            get => (int)GetValue(RatingProperty);
            set => SetValue(RatingProperty, value);
        }

        private static bool ValidateRating(object value)
        {
            int val = (int)value;
            return val >= 0 && val <= 5;
        }

        private static object CoerceRating(DependencyObject d, object baseValue)
        {
            int val = (int)baseValue;
            return Math.Min(Math.Max(val, 0), 5);
        }

        private static void OnRatingChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is RatingControl control)
            {
                control.UpdateStars();
                control.RaiseEvent(new RoutedEventArgs(RatingChangedEvent));
            }
        }

        // RoutedEvent (Bubbling)
        public static readonly RoutedEvent RatingChangedEvent =
            EventManager.RegisterRoutedEvent(
                nameof(RatingChanged),
                RoutingStrategy.Bubble,
                typeof(RoutedEventHandler),
                typeof(RatingControl));

        public event RoutedEventHandler RatingChanged
        {
            add => AddHandler(RatingChangedEvent, value);
            remove => RemoveHandler(RatingChangedEvent, value);
        }

        // Цвета звёзд для биндинга
        public Brush Star1Color => Rating >= 1 ? Brushes.Gold : Brushes.Gray;
        public Brush Star2Color => Rating >= 2 ? Brushes.Gold : Brushes.Gray;
        public Brush Star3Color => Rating >= 3 ? Brushes.Gold : Brushes.Gray;
        public Brush Star4Color => Rating >= 4 ? Brushes.Gold : Brushes.Gray;
        public Brush Star5Color => Rating >= 5 ? Brushes.Gold : Brushes.Gray;

        private void UpdateStars()
        {
            OnPropertyChanged(nameof(Star1Color));
            OnPropertyChanged(nameof(Star2Color));
            OnPropertyChanged(nameof(Star3Color));
            OnPropertyChanged(nameof(Star4Color));
            OnPropertyChanged(nameof(Star5Color));
        }

        private void Star_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && int.TryParse(button.CommandParameter.ToString(), out int star))
            {
                Rating = star;
            }
        }

        // INotifyPropertyChanged реализация
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
