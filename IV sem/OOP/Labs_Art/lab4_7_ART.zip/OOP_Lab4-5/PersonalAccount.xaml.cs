﻿using System;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace OOP_Lab4_5
{
    public partial class PersonalAccount : Window
    {
        public PersonalAccount()
        {
            InitializeComponent();
            LoadUserData();
        }

        private void LoadUserData()
        {
            // Загрузка данных пользователя (можно из файла или настроек)
            txtName.Text = Properties.Settings.Default.UserName ?? "Пользователь";
            txtEmail.Text = Properties.Settings.Default.UserEmail ?? "";
            txtPhone.Text = Properties.Settings.Default.UserPhone ?? "";

            // Установка текущей темы и языка
            foreach (ComboBoxItem item in cmbTheme.Items)
            {
                if (item.Tag.ToString() == Properties.Settings.Default.Theme)
                {
                    cmbTheme.SelectedItem = item;
                    break;
                }
            }

            foreach (ComboBoxItem item in cmbLanguage.Items)
            {
                if (item.Tag.ToString() == Properties.Settings.Default.Language)
                {
                    cmbLanguage.SelectedItem = item;
                    break;
                }
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.UserName = txtName.Text;
            Properties.Settings.Default.UserEmail = txtEmail.Text;
            Properties.Settings.Default.UserPhone = txtPhone.Text;
            Properties.Settings.Default.Save();

            MessageBox.Show("Данные сохранены", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ThemeChanged(object sender, RoutedEventArgs e)
        {
            if (cmbTheme.SelectedItem is ComboBoxItem selectedItem)
            {
                Properties.Settings.Default.Theme = selectedItem.Tag.ToString();
                ((App)Application.Current).ChangeTheme(selectedItem.Tag.ToString());
            }
        }

        private void LanguageChanged(object sender, RoutedEventArgs e)
        {
            if (cmbLanguage.SelectedItem is ComboBoxItem selectedItem)
            {
                Properties.Settings.Default.Language = selectedItem.Tag.ToString();
                CultureInfo lang = new CultureInfo(selectedItem.Tag.ToString());
                App.Language = lang;
            }
        }

        private void ChangePhoto_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png)|*.jpg;*.jpeg;*.png";

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    // Здесь можно сохранить фото пользователя
                    File.Copy(openFileDialog.FileName, "user_photo.jpg", true);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при загрузке фото: {ex.Message}", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void TextChanged_Log(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            string fieldName = textBox.Tag as string;
            string logMessage = $"{DateTime.Now}: Изменено поле '{fieldName}' на '{textBox.Text}'";

            File.AppendAllText("user_changes.log", logMessage + Environment.NewLine);
        }
    }
}