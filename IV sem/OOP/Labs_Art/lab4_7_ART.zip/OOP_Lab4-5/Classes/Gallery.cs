﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace OOP_Lab4_5.Classes
{
    [Serializable]
    public class Gallery
    {
        [XmlArray("BooksList"), XmlArrayItem("Book")]
        public List<Art> booksList;

        public Gallery() { booksList = new List<Art>(); }

        public void Add(Art m) => booksList.Add(m);   
    }
}
