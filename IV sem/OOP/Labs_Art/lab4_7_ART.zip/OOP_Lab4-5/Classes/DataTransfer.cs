﻿using System.IO;
using System.Xml.Serialization;
using OOP_Lab4_5.Classes;

namespace OOP_Lab4_5
{
    public static class DataTransfer
    {
        public static void SerializeBooks(Gallery books)
        {
            var serializer = new XmlSerializer(typeof(Gallery));
            using (var fs = new FileStream(@"C:\ооп\OOP_Lab4-5\OOP_Lab4-5\Resources\art.xml", FileMode.Create))
            {
                serializer.Serialize(fs, books);
            }
        }


        public static Gallery DeserializeBooks()
        {
            var serializer = new XmlSerializer(typeof(Gallery));
            Gallery deserializedBooksList = null;

            using (var fs = new FileStream(@"C:\ооп\OOP_Lab4-5\OOP_Lab4-5\Resources\art.xml", FileMode.OpenOrCreate))
            {
                if (fs.Length > 0)
                    deserializedBooksList = serializer.Deserialize(fs) as Gallery;
            }

            return deserializedBooksList;
        }
    }
}
