﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using System.Windows;

namespace OOP_Lab4_5
{
    public partial class App : Application
    {
        private static List<CultureInfo> m_Languages = new List<CultureInfo>();
        public static event EventHandler LanguageChanged;

        public static List<CultureInfo> SupportedLanguages
        {
            get { return m_Languages; }
        }

        public App()
        {
            m_Languages.Clear();
            m_Languages.Add(new CultureInfo("en-US"));
            m_Languages.Add(new CultureInfo("ru-RU"));
        }

        // Новый метод для смены темы

        public void ChangeTheme(string themeName)
        {
            // Удаляем текущую тему
            var oldThemeDict = Resources.MergedDictionaries
                .FirstOrDefault(d => d.Source?.OriginalString.EndsWith("Theme.xaml") == true);

            if (oldThemeDict != null)
            {
                Resources.MergedDictionaries.Remove(oldThemeDict);
            }

            // Формируем путь к теме (используем классический switch)
            string themeFile;
            switch (themeName)
            {
                case "Dark":
                    themeFile = "BlackTheme.xaml";
                    break;
                case "Pink":
                    themeFile = "PinkTheme.xaml";
                    break;
                case "Gray":
                    themeFile = "GrayTheme.xaml";
                    break;
                default:
                    themeFile = "LightTheme.xaml"; // По умолчанию светлая тема
                    break;
            }

            try
            {
                var themeDict = new ResourceDictionary
                {
                    Source = new Uri($"Styles/{themeFile}", UriKind.Relative)
                };
                Resources.MergedDictionaries.Add(themeDict);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось загрузить тему '{themeName}': {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public static CultureInfo Language
        {
            get
            {
                return System.Threading.Thread.CurrentThread.CurrentUICulture;
            }
            set
            {
                if (value == null) throw new ArgumentNullException("value");
                if (value == System.Threading.Thread.CurrentThread.CurrentUICulture) return;

                System.Threading.Thread.CurrentThread.CurrentUICulture = value;

                ResourceDictionary dict = new ResourceDictionary();
                switch (value.Name)
                {
                    case "ru-RU":
                        dict.Source = new Uri("Dictionaries/RussianDictionary.xaml", UriKind.Relative);
                        break;
                    default:
                        dict.Source = new Uri("Dictionaries/EnglishDictionary.xaml", UriKind.Relative);
                        break;
                }

                var oldDict = Current.Resources.MergedDictionaries
                    .FirstOrDefault(d => d.Source?.OriginalString.Contains("Dictionary.xaml") == true);

                if (oldDict != null)
                {
                    int ind = Current.Resources.MergedDictionaries.IndexOf(oldDict);
                    Current.Resources.MergedDictionaries.Remove(oldDict);
                    Current.Resources.MergedDictionaries.Insert(ind, dict);
                }
                else
                {
                    Current.Resources.MergedDictionaries.Add(dict);
                }

                LanguageChanged?.Invoke(Application.Current, EventArgs.Empty);
            }
        }
    }
}