﻿using System;
using System.Windows;

namespace OOP_Lab4_5
{
    /// <summary>
    /// Логика взаимодействия для AboutAtrMarket.xaml
    /// </summary>
    public partial class AboutAtrMarket : Window
    {
        public AboutAtrMarket()
        {
            InitializeComponent();

            // Дополнительная инициализация при необходимости
            this.Loaded += AboutAtrMarket_Loaded;
        }

        private void AboutAtrMarket_Loaded(object sender, RoutedEventArgs e)
        {
            // Можно добавить код, который выполняется после загрузки окна
            // Например, загрузку дополнительных данных или настройку UI
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            // Закрытие окна
            this.Close();

            // Альтернативный вариант с анимацией:
            // var anim = new DoubleAnimation(0, TimeSpan.FromSeconds(0.3));
            // anim.Completed += (s, _) => this.Close();
            // this.BeginAnimation(UIElement.OpacityProperty, anim);
        }
    }
}