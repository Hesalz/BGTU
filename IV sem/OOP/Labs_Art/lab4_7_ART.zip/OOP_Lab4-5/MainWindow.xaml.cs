﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace OOP_Lab4_5
{
    public partial class MainWindow : Window
    {
        private bool styleCheck = false;

        public MainWindow()
        {
            InitializeComponent();

            var uri = new Uri("./Styles/WhiteTheme.xaml", UriKind.Relative);
            var resourceDict = Application.LoadComponent(uri) as ResourceDictionary;
            Application.Current.Resources.MergedDictionaries.Add(resourceDict);

            var sri = Application.GetResourceStream(new Uri("./Styles/arrow.cur", UriKind.Relative));
            var customCursor = new Cursor(sri.Stream);
            Cursor = customCursor;

            App.LanguageChanged += languageChanged;
            CultureInfo currLang = App.Language;
        }

        private void languageChanged(Object sender, EventArgs e)
        {
            CultureInfo currLang = App.Language;
        }

        private void buttonRu_Click(object sender, RoutedEventArgs e)
        {
            CultureInfo lang = new CultureInfo("ru-RU");
            App.Language = lang;
        }

        private void buttonEng_Click(object sender, RoutedEventArgs e)
        {
            CultureInfo lang = new CultureInfo("en-US");
            App.Language = lang;
        }

        private void darkTheme_Click(object sender, RoutedEventArgs e)
        {
            // Использование нового метода
            ChangeTheme(styleCheck ? "Black" : "White");
            styleCheck = !styleCheck;
        }

        private void viewBooks_Click(object sender, RoutedEventArgs e)
        {
            ViewAllBooks viewAllBooks = new ViewAllBooks();
            viewAllBooks.Show();
            this.Close();
        }

        private void ChangeColor_Click(object sender, RoutedEventArgs e)
        {
            var currentColor = (Color)FindResource("DynamicColor");
            var newColor = Color.FromRgb(
                (byte)(255 - currentColor.R),
                (byte)(255 - currentColor.G),
                (byte)(255 - currentColor.B));
            this.Resources["DynamicColor"] = newColor;
        }

        private void aboutButton_Click(object sender, RoutedEventArgs e)
        {
            var aboutWindow = new AboutAtrMarket();
            aboutWindow.Owner = this;
            aboutWindow.ShowDialog();
        }
        private void accountButton_Click(object sender, RoutedEventArgs e)
        {
            var accountWindow = new PersonalAccount();
            accountWindow.Owner = this;
            accountWindow.ShowDialog();
        }
        // Новый универсальный метод смены темы
        private void ChangeTheme(string themeName)
        {
            var currentTheme = Application.Current.Resources.MergedDictionaries
                .FirstOrDefault(d => d.Source != null && d.Source.ToString().Contains("Theme.xaml"));

            if (currentTheme != null)
            {
                Application.Current.Resources.MergedDictionaries.Remove(currentTheme);
            }

            var newTheme = new ResourceDictionary();

            switch (themeName)
            {
                case "Black":
                    newTheme.Source = new Uri("./Styles/BlackTheme.xaml", UriKind.Relative);
                    break;
                case "White":
                    newTheme.Source = new Uri("./Styles/WhiteTheme.xaml", UriKind.Relative);
                    break;
                case "Pink":
                    newTheme.Source = new Uri("./Styles/PinkTheme.xaml", UriKind.Relative);
                    break;
                case "Gray":
                    newTheme.Source = new Uri("./Styles/GrayTheme.xaml", UriKind.Relative);
                    break;
            }

            Application.Current.Resources.MergedDictionaries.Add(newTheme);
        }
    }
}