﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace OOP_Lab4_5
{
    public partial class DateSelectorControl : UserControl
    {
        public DateSelectorControl()
        {
            InitializeComponent();
        }

        public static readonly DependencyProperty SelectedDateProperty =
            DependencyProperty.Register(
                nameof(SelectedDate),
                typeof(DateTime),
                typeof(DateSelectorControl),
                new FrameworkPropertyMetadata(DateTime.Today,
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                    OnSelectedDateChanged,
                    CoerceDate),
                ValidateDate);

        public DateTime SelectedDate
        {
            get => (DateTime)GetValue(SelectedDateProperty);
            set => SetValue(SelectedDateProperty, value);
        }

        private static bool ValidateDate(object value)
        {
            if (value is DateTime date)
            {
                return date <= DateTime.Today;
            }
            return false;
        }

        private static object CoerceDate(DependencyObject d, object baseValue)
        {
            if (baseValue is DateTime date && date > DateTime.Today)
                return DateTime.Today;
            return baseValue;
        }

        private static void OnSelectedDateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is DateSelectorControl control)
            {
                control.RaiseEvent(new RoutedEventArgs(DateChangedEvent));
            }
        }

        // RoutedEvent (Bubbling)
        public static readonly RoutedEvent DateChangedEvent =
            EventManager.RegisterRoutedEvent(
                nameof(DateChanged),
                RoutingStrategy.Bubble,
                typeof(RoutedEventHandler),
                typeof(DateSelectorControl));

        public event RoutedEventHandler DateChanged
        {
            add => AddHandler(DateChangedEvent, value);
            remove => RemoveHandler(DateChangedEvent, value);
        }
    }
}
