﻿using System;
using System.Collections.Generic;
using OOP_Lab4_5.Classes;

namespace OOP_Lab4_5
{
    public class CommandManager
    {
        private Stack<ICommand> undoStack = new Stack<ICommand>();
        private Stack<ICommand> redoStack = new Stack<ICommand>();

        public void ExecuteCommand(ICommand command)
        {
            command.Execute();
            undoStack.Push(command);
            redoStack.Clear();
        }

        public void Undo()
        {
            if (undoStack.Count > 0)
            {
                ICommand command = undoStack.Pop();
                command.Undo();
                redoStack.Push(command);
            }
        }

        public void Redo()
        {
            if (redoStack.Count > 0)
            {
                ICommand command = redoStack.Pop();
                command.Execute();
                undoStack.Push(command);
            }
        }
    }

    public interface ICommand
    {
        void Execute();
        void Undo();
    }

    public class AddArtCommand : ICommand
    {
        private Gallery _gallery;
        private Art _art;

        public AddArtCommand(Gallery gallery, Art art)
        {
            _gallery = gallery;
            _art = art;
        }

        public void Execute()
        {
            _gallery.Add(_art);
            DataTransfer.SerializeBooks(_gallery);
        }

        public void Undo()
        {
            _gallery.booksList.Remove(_art);
            DataTransfer.SerializeBooks(_gallery);
        }
    }

    public class DeleteArtCommand : ICommand
    {
        private Gallery _gallery;
        private Art _art;
        private int _index;

        public DeleteArtCommand(Gallery gallery, Art art)
        {
            _gallery = gallery;
            _art = art;
            _index = gallery.booksList.IndexOf(art);
        }

        public void Execute()
        {
            _gallery.booksList.Remove(_art);
            DataTransfer.SerializeBooks(_gallery);
        }

        public void Undo()
        {
            if (_index >= 0 && _index <= _gallery.booksList.Count)
                _gallery.booksList.Insert(_index, _art);
            else
                _gallery.booksList.Add(_art);

            DataTransfer.SerializeBooks(_gallery);
        }
    }
}