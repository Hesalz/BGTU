﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace FlowerShopADO
{
    public static class DataAccess
    {
        public static string MasterConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["MasterConn"].ConnectionString; }
        }
        public static string DatabaseConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["FlowerShopConn"].ConnectionString; }
        }

        public static void EnsureDatabaseAndUser()
        {
            SqlConnection connection = null;
            SqlCommand cmd = null;
            try
            {
                connection = new SqlConnection(MasterConnectionString);
                connection.Open();

                string createDbSql = @"
IF DB_ID('FlowerShop_ADO') IS NULL
BEGIN
    CREATE DATABASE FlowerShop_ADO;
END
";
                cmd = new SqlCommand(createDbSql, connection);
                cmd.ExecuteNonQuery();
                cmd.Dispose();

                string createTablesSql = @"
USE FlowerShop_ADO;

IF OBJECT_ID('Brands', 'U') IS NULL
BEGIN
    CREATE TABLE Brands (
        Id INT IDENTITY PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL
    );
END

IF OBJECT_ID('Flowers', 'U') IS NULL
BEGIN
    CREATE TABLE Flowers (
        Id INT IDENTITY PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Price MONEY NOT NULL,
        Color NVARCHAR(50) NOT NULL,
        Photo VARBINARY(MAX) NOT NULL,
        BrandId INT FOREIGN KEY REFERENCES Brands(Id)
    );
END
";
                cmd = new SqlCommand(createTablesSql, connection);
                cmd.ExecuteNonQuery();
                cmd.Dispose();

                string procs = @"
USE FlowerShop_ADO;

IF OBJECT_ID('usp_AddFlower', 'P') IS NULL
EXEC('CREATE PROCEDURE usp_AddFlower
    @Name NVARCHAR(100),
    @Price MONEY,
    @Color NVARCHAR(50),
    @Photo VARBINARY(MAX),
    @BrandId INT
AS
BEGIN
    INSERT INTO Flowers (Name, Price, Color, Photo, BrandId)
    VALUES (@Name, @Price, @Color, @Photo, @BrandId)
END');

IF OBJECT_ID('usp_UpdateFlower', 'P') IS NULL
EXEC('CREATE PROCEDURE usp_UpdateFlower
    @Id INT,
    @Name NVARCHAR(100),
    @Price MONEY,
    @Color NVARCHAR(50),
    @Photo VARBINARY(MAX),
    @BrandId INT
AS
BEGIN
    UPDATE Flowers SET Name=@Name, Price=@Price, Color=@Color, Photo=@Photo, BrandId=@BrandId WHERE Id=@Id
END');

IF OBJECT_ID('usp_DeleteFlower', 'P') IS NULL
EXEC('CREATE PROCEDURE usp_DeleteFlower
    @Id INT
AS
BEGIN
    DELETE FROM Flowers WHERE Id=@Id
END');

IF OBJECT_ID('usp_AddBrand', 'P') IS NULL
EXEC('CREATE PROCEDURE usp_AddBrand
    @Name NVARCHAR(100)
AS
BEGIN
    INSERT INTO Brands (Name) VALUES (@Name)
END');

IF OBJECT_ID('usp_UpdateBrand', 'P') IS NULL
EXEC('CREATE PROCEDURE usp_UpdateBrand
    @Id INT,
    @Name NVARCHAR(100)
AS
BEGIN
    UPDATE Brands SET Name=@Name WHERE Id=@Id
END');

IF OBJECT_ID('usp_DeleteBrand', 'P') IS NULL
EXEC('CREATE PROCEDURE usp_DeleteBrand
    @Id INT
AS
BEGIN
    DELETE FROM Brands WHERE Id=@Id
END');
";
                cmd = new SqlCommand(procs, connection);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (connection != null) connection.Dispose();
            }
        }

        public static DataTable ExecuteQuery(string sql, SqlParameter[] parameters)
        {
            SqlConnection conn = null;
            SqlCommand cmd = null;
            SqlDataAdapter adapter = null;
            DataTable dt = new DataTable();
            try
            {
                conn = new SqlConnection(DatabaseConnectionString);
                cmd = new SqlCommand(sql, conn);
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            finally
            {
                if (adapter != null) adapter.Dispose();
                if (cmd != null) cmd.Dispose();
                if (conn != null) conn.Dispose();
            }
            return dt;
        }

        public static int ExecuteStoredProcedure(string procedureName, SqlParameter[] parameters)
        {
            SqlConnection conn = null;
            SqlTransaction tran = null;
            SqlCommand cmd = null;
            int result = 0;
            try
            {
                conn = new SqlConnection(DatabaseConnectionString);
                conn.Open();
                tran = conn.BeginTransaction();
                cmd = new SqlCommand(procedureName, conn, tran);
                cmd.CommandType = CommandType.StoredProcedure;
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                result = cmd.ExecuteNonQuery();
                tran.Commit();
            }
            catch (Exception ex)
            {
                if (tran != null)
                {
                    try { tran.Rollback(); } catch { }
                }
                MessageBox.Show("Ошибка при выполнении операции: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (cmd != null) cmd.Dispose();
                if (tran != null) tran.Dispose();
                if (conn != null) conn.Dispose();
            }
            return result;
        }
    }
}
