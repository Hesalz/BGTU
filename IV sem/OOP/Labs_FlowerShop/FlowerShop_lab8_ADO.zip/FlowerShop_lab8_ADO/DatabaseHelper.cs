﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace FlowerShopADO
{
    public static class DatabaseHelper
    {
        private static readonly string DatabaseName = "FlowerShop_ADO";
        private static readonly string MasterConnectionString = ConfigurationManager.ConnectionStrings["MasterConn"].ConnectionString;
        private static readonly string TargetConnectionString = ConfigurationManager.ConnectionStrings["FlowerShopConn"].ConnectionString;

        public static void EnsureDatabaseExists()
        {
            if (!CanConnectToDatabase(TargetConnectionString))
            {
                CreateDatabase();
            }
        }

        private static bool CanConnectToDatabase(string connectionString)
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(connectionString);
                connection.Open();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                if (connection != null) connection.Dispose();
            }
        }

        private static void CreateDatabase()
        {
            string createDbQuery = "IF DB_ID('" + DatabaseName + "') IS NULL CREATE DATABASE [" + DatabaseName + "]";
            SqlConnection connection = null;
            SqlCommand command = null;
            try
            {
                connection = new SqlConnection(MasterConnectionString);
                connection.Open();
                command = new SqlCommand(createDbQuery, connection);
                command.ExecuteNonQuery();
            }
            finally
            {
                if (command != null) command.Dispose();
                if (connection != null) connection.Dispose();
            }
        }
    }
}
