﻿using System;
using System.Data;
using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace FlowerShopADO
{
    public partial class AddEditFlowerWindow : Window
    {
        public string FlowerName { get; private set; }
        public decimal Price { get; private set; }
        public string Color { get; private set; }
        public int BrandId { get; private set; }
        public byte[] PhotoBytes { get; set; }

        public AddEditFlowerWindow()
        {
            InitializeComponent();
            LoadBrands();
        }

        private void LoadBrands()
        {
            string sql = "SELECT Id, Name FROM Brands";
            DataTable brands = DataAccess.ExecuteQuery(sql, null);
            cmbBrands.ItemsSource = brands.DefaultView;
        }

        private void ChoosePhoto_Click(object sender, RoutedEventArgs e)
        {
            var ofd = new OpenFileDialog { Filter = "Картинки|*.png;*.jpg;*.jpeg;*.bmp" };
            if (ofd.ShowDialog() == true)
            {
                PhotoBytes = File.ReadAllBytes(ofd.FileName);
                txtPhotoPath.Text = System.IO.Path.GetFileName(ofd.FileName);
            }
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название цветка!");
                return;
            }
            decimal price;
            if (!decimal.TryParse(txtPrice.Text, out price))
            {
                MessageBox.Show("Введите корректную цену!");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtColor.Text))
            {
                MessageBox.Show("Введите цвет!");
                return;
            }
            if (cmbBrands.SelectedValue == null)
            {
                MessageBox.Show("Выберите поставщика!");
                return;
            }
            if (PhotoBytes == null || PhotoBytes.Length == 0)
            {
                MessageBox.Show("Добавьте фото цветка! Это обязательное поле.");
                return;
            }

            FlowerName = txtName.Text;
            Price = price;
            Color = txtColor.Text;
            BrandId = (int)cmbBrands.SelectedValue;

            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
