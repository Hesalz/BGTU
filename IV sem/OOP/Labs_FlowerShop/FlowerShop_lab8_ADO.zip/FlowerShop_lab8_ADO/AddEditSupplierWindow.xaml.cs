﻿using System.Windows;

namespace FlowerShopADO
{
    public partial class AddEditBrandWindow : Window
    {
        public string BrandName { get; private set; }

        public AddEditBrandWindow()
        {
            InitializeComponent();
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название поставщика!");
                return;
            }
            BrandName = txtName.Text;
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
