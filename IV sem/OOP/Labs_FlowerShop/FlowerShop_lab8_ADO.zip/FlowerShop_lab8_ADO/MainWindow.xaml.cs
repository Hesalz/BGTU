﻿using System;
using System.Data;
using System.Windows;
using System.Data.SqlClient;

namespace FlowerShopADO
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DatabaseHelper.EnsureDatabaseExists();
            DataAccess.EnsureDatabaseAndUser();
            LoadFlowers();
        }

        private void LoadFlowers()
        {
            string sql = @"
SELECT f.Id, f.Name, f.Price, f.Color, f.Photo, b.Name AS BrandName, f.BrandId
FROM Flowers f
JOIN Brands b ON f.BrandId = b.Id";
            dgFlowers.ItemsSource = DataAccess.ExecuteQuery(sql, null).DefaultView;
        }


        private void AddFlower_Click(object sender, RoutedEventArgs e)
        {
            var win = new AddEditFlowerWindow();
            if (win.ShowDialog() == true)
            {
                SqlConnection conn = null;
                SqlTransaction tran = null;
                SqlCommand cmd = null;
                try
                {
                    conn = new SqlConnection(DataAccess.DatabaseConnectionString);
                    conn.Open();
                    tran = conn.BeginTransaction();

                    cmd = new SqlCommand("usp_AddFlower", conn, tran);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name", win.FlowerName);
                    cmd.Parameters.AddWithValue("@Price", win.Price);
                    cmd.Parameters.AddWithValue("@Color", win.Color);
                    cmd.Parameters.AddWithValue("@Photo", win.PhotoBytes);
                    cmd.Parameters.AddWithValue("@BrandId", win.BrandId);

                    cmd.ExecuteNonQuery();

                    tran.Commit();
                    LoadFlowers();
                }
                catch (Exception ex)
                {
                    if (tran != null)
                    {
                        try { tran.Rollback(); } catch { }
                    }
                    MessageBox.Show("Ошибка при добавлении цветка: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    if (cmd != null) cmd.Dispose();
                    if (tran != null) tran.Dispose();
                    if (conn != null) conn.Dispose();
                }
            }
        }


        private void EditFlower_Click(object sender, RoutedEventArgs e)
        {
            var row = dgFlowers.SelectedItem as DataRowView;
            if (row != null)
            {
                var win = new AddEditFlowerWindow();
                win.txtName.Text = row["Name"].ToString();
                win.txtPrice.Text = row["Price"].ToString();
                win.txtColor.Text = row["Color"].ToString();
                win.cmbBrands.SelectedValue = row["BrandId"];
                win.PhotoBytes = (byte[])row["Photo"];
                if (win.ShowDialog() == true)
                {
                    var pars = new[]
                    {
                        new SqlParameter("@Id", (int)row["Id"]),
                        new SqlParameter("@Name", win.FlowerName),
                        new SqlParameter("@Price", win.Price),
                        new SqlParameter("@Color", win.Color),
                        new SqlParameter("@Photo", win.PhotoBytes),
                        new SqlParameter("@BrandId", win.BrandId)
                    };
                    DataAccess.ExecuteStoredProcedure("usp_UpdateFlower", pars);
                    LoadFlowers();
                }
            }
            else
            {
                MessageBox.Show("Выберите цветок для редактирования.");
            }
        }

        private void DeleteFlower_Click(object sender, RoutedEventArgs e)
        {
            var row = dgFlowers.SelectedItem as DataRowView;
            if (row != null)
            {
                int id = (int)row["Id"];
                if (MessageBox.Show("Удалить выбранный цветок?", "Удаление", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    var pars = new[] { new SqlParameter("@Id", id) };
                    DataAccess.ExecuteStoredProcedure("usp_DeleteFlower", pars);
                    LoadFlowers();
                }
            }
            else
            {
                MessageBox.Show("Выберите цветок для удаления.");
            }
        }

        private void AddBrand_Click(object sender, RoutedEventArgs e)
        {
            var win = new AddEditBrandWindow();
            if (win.ShowDialog() == true)
            {
                var pars = new[]
                {
                    new SqlParameter("@Name", win.BrandName)
                };
                DataAccess.ExecuteStoredProcedure("usp_AddBrand", pars);
                LoadFlowers();
            }
        }

        private void EditBrand_Click(object sender, RoutedEventArgs e)
        {
            var row = dgFlowers.SelectedItem as DataRowView;
            if (row != null)
            {
                int brandId = (int)row["BrandId"];
                string oldName = row["BrandName"].ToString();

                var win = new AddEditBrandWindow();
                win.txtName.Text = oldName;
                if (win.ShowDialog() == true)
                {
                    var pars = new[]
                    {
                        new SqlParameter("@Id", brandId),
                        new SqlParameter("@Name", win.BrandName)
                    };
                    DataAccess.ExecuteStoredProcedure("usp_UpdateBrand", pars);
                    LoadFlowers();
                }
            }
            else
            {
                MessageBox.Show("Сначала выберите цветок, чтобы изменить его поставщика.");
            }
        }

        private void DeleteBrand_Click(object sender, RoutedEventArgs e)
        {
            var row = dgFlowers.SelectedItem as DataRowView;
            if (row != null)
            {
                int brandId = (int)row["BrandId"];
                string sql = "SELECT COUNT(*) FROM Flowers WHERE BrandId=@BrandId";
                var pars = new[] { new SqlParameter("@BrandId", brandId) };
                DataTable dt = DataAccess.ExecuteQuery(sql, pars);
                int count = Convert.ToInt32(dt.Rows[0][0]);
                if (count > 1)
                {
                    MessageBox.Show("Нельзя удалить поставщика, пока к нему привязаны цветы (кроме выбранного).");
                    return;
                }
                if (MessageBox.Show("Удалить поставщика? Цветок тоже будет удалён!", "Удаление поставщика", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    int flowerId = (int)row["Id"];
                    DataAccess.ExecuteStoredProcedure("usp_DeleteFlower", new[] { new SqlParameter("@Id", flowerId) });
                    DataAccess.ExecuteStoredProcedure("usp_DeleteBrand", new[] { new SqlParameter("@Id", brandId) });
                    LoadFlowers();
                }
            }
            else
            {
                MessageBox.Show("Сначала выберите цветок, чтобы удалить его поставщика.");
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            LoadFlowers();
        }
    }
}
