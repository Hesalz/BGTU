﻿using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace FlowerShopWPF.Models
{
    public static class ImageConverter
    {
        public static byte[] ImageToByte(BitmapImage image)
        {
            if (image == null) return null;
            using (MemoryStream ms = new MemoryStream())
            {
                JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(image));
                encoder.Save(ms);
                return ms.ToArray();
            }
        }

        public static BitmapImage ByteToImage(byte[] data)
        {
            if (data == null) return null;
            BitmapImage image = new BitmapImage();
            using (MemoryStream ms = new MemoryStream(data))
            {
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.StreamSource = ms;
                image.EndInit();
            }
            return image;
        }
    }

    public class FirstImageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var images = value as System.Collections.Generic.ICollection<FlowerImage>;
            if (images != null && images.Any() && images.First().ImageData != null)
                return ImageConverter.ByteToImage(images.First().ImageData);
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class NoImageVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var images = value as System.Collections.ICollection;
            if (images == null || images.Count == 0)
                return Visibility.Visible;
            return Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
