﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using FlowerShopWPF.Models;

public class FlowerImage
{
    [Key]
    public int Id { get; set; }
    public byte[] ImageData { get; set; }

    [ForeignKey("Flower")]
    public int FlowerId { get; set; }
    public virtual Flower Flower { get; set; }
}