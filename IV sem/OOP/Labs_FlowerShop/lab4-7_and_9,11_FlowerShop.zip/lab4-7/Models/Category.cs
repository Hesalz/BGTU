﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FlowerShopWPF.Models
{
    public class Category
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public virtual ICollection<Flower> Flowers { get; set; }
    }
}
