﻿using System.Data.Entity;

namespace FlowerShopWPF.Models
{
    public class FlowerContext : DbContext
    {
        public FlowerContext() : base("name=FlowerShopDB")
        {
            Database.SetInitializer(new FlowerDbInitializer());
        }

        public DbSet<Flower> Flowers { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<FlowerImage> FlowerImages { get; set; }

        private class FlowerDbInitializer : CreateDatabaseIfNotExists<FlowerContext>
        {
            protected override void Seed(FlowerContext context)
            {
                context.Categories.Add(new Category { Name = "Розы" });
                context.Categories.Add(new Category { Name = "Тюльпаны" });
                context.Categories.Add(new Category { Name = "Лилии" });

                context.SaveChanges();

                base.Seed(context);
            }
        }
    }
}
