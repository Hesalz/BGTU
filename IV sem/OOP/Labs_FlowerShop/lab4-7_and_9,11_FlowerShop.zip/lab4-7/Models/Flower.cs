﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FlowerShopWPF.Models
{
    public class Flower
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string ShortName { get; set; }
        public string FullName { get; set; }
        public string Description { get; set; }
        public virtual ICollection<FlowerImage> Images { get; set; } = new List<FlowerImage>();

        [ForeignKey("Category")]
        public int CategoryId { get; set; }
        public virtual Category Category { get; set; }

        public double Rating { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public string Color { get; set; }
        public string Size { get; set; }
        public string CountryOfDelivery { get; set; }
        public decimal Discount { get; set; }
        public bool IsOutOfStock { get; set; }
        public virtual ICollection<Flower> RelatedFlowers { get; set; }
        public int PurchasedCount { get; set; }
        public string Manufacturer { get; set; }
    }
}
