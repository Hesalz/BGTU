﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace FlowerShopWPF.Models
{
    public class InStockConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isOutOfStock)
                return isOutOfStock ? "Нет в наличии" : "В наличии";
            return "Неизвестно";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string str)
                return str == "Нет в наличии";
            return false;
        }
    }
}
