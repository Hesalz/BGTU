﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using FlowerShopWPF.Models;

namespace FlowerShopWPF.Views
{
    public partial class CatalogWindow : Window
    {
        private FlowerContext _context = new FlowerContext();
        private List<Flower> _allFlowers = new List<Flower>();

        public CatalogWindow()
        {
            InitializeComponent();

            try
            {
                string cursorUri = "pack://application:,,,/resourсes/Cursors/Arrow.ani";
                var resourceInfo = Application.GetResourceStream(new Uri(cursorUri));

                if (resourceInfo != null && resourceInfo.Stream != null)
                {
                    this.Cursor = new Cursor(resourceInfo.Stream);
                }
                else
                {
                    this.Cursor = Cursors.Arrow;
                    MessageBox.Show($"Курсор не найден по пути: {cursorUri}");
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Arrow;
                MessageBox.Show($"Ошибка при установке курсора: {ex.Message}");
            }

            LoadData();
        }

        private void LoadData()
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    _context.Categories.Load();
                    _context.Flowers.Include(f => f.Category).Include(f => f.Images).Load();

                    var allCategory = new Category { Id = 0, Name = "Все" };
                    var categories = _context.Categories.Local.ToList();
                    categories.Insert(0, allCategory);
                    CategoryBox.ItemsSource = categories;
                    CategoryBox.SelectedIndex = 0;

                    _allFlowers = _context.Flowers.Local.ToList();

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
                }
            }

            _ = ApplyFilterAsync(); // Запускаем фильтрацию после загрузки
        }

        private void FilterChanged(object sender, EventArgs e)
        {
            _ = ApplyFilterAsync();
        }

        private async Task ApplyFilterAsync()
        {
            using (var transaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
            {
                try
                {
                    IQueryable<Flower> filtered = _context.Flowers.Include(f => f.Category).Include(f => f.Images);

                    string search = SearchBox.Text?.Trim().ToLower() ?? "";
                    if (!string.IsNullOrWhiteSpace(search))
                        filtered = filtered.Where(f => f.ShortName != null && f.ShortName.ToLower().Contains(search));

                    var selectedCategory = CategoryBox.SelectedItem as Category;
                    if (selectedCategory != null && selectedCategory.Id != 0)
                        filtered = filtered.Where(f => f.CategoryId == selectedCategory.Id);

                    if (decimal.TryParse(PriceFromBox.Text, out decimal priceFrom))
                        filtered = filtered.Where(f => f.Price >= priceFrom);

                    if (decimal.TryParse(PriceToBox.Text, out decimal priceTo))
                        filtered = filtered.Where(f => f.Price <= priceTo);

                    var result = await filtered.ToListAsync();

                    FlowersGrid.ItemsSource = result;

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show($"Ошибка при фильтрации: {ex.Message}");
                }
            }
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            var settingsWindow = new UserSettingsWindow();
            settingsWindow.Owner = this;
            settingsWindow.ShowDialog();
        }

        public void UpdateDataGridHeaders()
        {
            FlowersGrid.Columns[0].Header = TryFindResource("ShortName") ?? "Краткое название";
            FlowersGrid.Columns[1].Header = TryFindResource("Category") ?? "Категория";
            FlowersGrid.Columns[2].Header = TryFindResource("Price") ?? "Цена";
            FlowersGrid.Columns[3].Header = TryFindResource("Quantity") ?? "Количество";
            FlowersGrid.Columns[4].Header = TryFindResource("Have") ?? "В наличии";
            FlowersGrid.Columns[5].Header = TryFindResource("Photo") ?? "Фото";
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            var roleWindow = new RoleSelectionWindow();
            Application.Current.MainWindow = roleWindow;
            roleWindow.Show();
            this.Close();
        }
    }
}
