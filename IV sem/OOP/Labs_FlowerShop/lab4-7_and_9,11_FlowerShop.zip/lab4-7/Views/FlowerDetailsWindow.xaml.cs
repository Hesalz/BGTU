﻿using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using FlowerShopWPF.Models;

namespace FlowerShopWPF.Views
{
    public partial class FlowerDetailsWindow : Window
    {
        private FlowerContext _context = new FlowerContext();
        private Flower _flower;
        private BitmapImage _selectedImage;
        private byte[] _selectedImageData;
        private FlowerImage _currentImage;
        private bool _isNew = false;
        private bool _previewMouseDownHandled = false;
        private bool _mouseDownHandled = false;
        private bool _gotFocusHandled = false;


        public FlowerDetailsWindow(FlowerContext context, Flower flower)
        {
            InitializeComponent();
            _context = context;
            try
            {
                string cursorUri = "pack://application:,,,/resourсes/Cursors/Arrow.ani";
                var resourceInfo = Application.GetResourceStream(new Uri(cursorUri));

                if (resourceInfo != null && resourceInfo.Stream != null)
                {
                    this.Cursor = new Cursor(resourceInfo.Stream);
                }
                else
                {
                    this.Cursor = Cursors.Arrow;
                    MessageBox.Show($"Курсор не найден по пути: {cursorUri}");
                }
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Arrow;
                MessageBox.Show($"Ошибка при установке курсора: {ex.Message}");
            }
            CategoryBox.ItemsSource = _context.Categories.ToList();

            if (flower == null)
            {
                _flower = new Flower();
                _isNew = true;
                Title = "Добавить цветок";
            }
            else
            {
                _flower = _context.Flowers.Include("Images").FirstOrDefault(f => f.Id == flower.Id);
                Title = "Редактировать цветок";
            }

            LoadData();

            DescriptionBox.AddHandler(UIElement.PreviewMouseLeftButtonDownEvent,
    new MouseButtonEventHandler(DescriptionBox_MouseDown), true);
        }

        public static readonly DependencyProperty FullNameProperty = DependencyProperty.Register(
    "FullName",
    typeof(string),
    typeof(FlowerDetailsWindow),
    new FrameworkPropertyMetadata(
        null,
        FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
        null,
        CoerceFullName),
    ValidateFullName);

        public string FullName
        {
            get => (string)GetValue(FullNameProperty);
            set => SetValue(FullNameProperty, value);
        }

        private static bool ValidateFullName(object value)
        {
            return value == null || value is string;
        }

        private static object CoerceFullName(DependencyObject d, object baseValue)
        {
            if (baseValue is string str)
            {
                if (str.Length > 15)
                    return str.Substring(0, 15);

                return str;
            }

            return baseValue;
        }
        private string BuildRoute(RoutedEventArgs e)
        {
            var route = e.Source.GetType().Name + " → ";
            var current = (DependencyObject)e.Source;
            while ((current = VisualTreeHelper.GetParent(current)) != null)
            {
                route += current.GetType().Name + " → ";
            }
            return route.TrimEnd(' ', '→');
        }

        private void DescriptionBox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (_previewMouseDownHandled) return;
            MessageBox.Show("[Tunneling] PreviewMouseDown: " + BuildRoute(e));
            _previewMouseDownHandled = true;
            e.Handled = false;
        }

        private async void DescriptionBox_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (_mouseDownHandled) return;
            await Task.Delay(100);
            MessageBox.Show("[Bubbling] MouseDown: " + BuildRoute(e));
            _mouseDownHandled = true;
        }

        private async void DescriptionBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (_gotFocusHandled) return;
            await Task.Delay(100);
            MessageBox.Show("[Direct] GotFocus: " + BuildRoute(e));
            _gotFocusHandled = true;
        }


        private void LoadData()
        {
            ShortNameBox.Text = _flower.ShortName;
            FullName = _flower.FullName;
            DescriptionBox.Text = _flower.Description;
            CategoryBox.SelectedItem = _context.Categories.FirstOrDefault(c => c.Id == _flower.CategoryId);
            PriceBox.Text = _flower.Price.ToString();
            QuantityBox.Text = _flower.Quantity.ToString();
            OutOfStockCheck.IsChecked = _flower.IsOutOfStock;

            _currentImage = _flower.Images?.FirstOrDefault();
            if (_currentImage != null && _currentImage.ImageData != null)
            {
                _selectedImageData = _currentImage.ImageData;
                _selectedImage = ImageConverter.ByteToImage(_currentImage.ImageData);
                FlowerImage.Source = _selectedImage;
                NoImageText.Visibility = Visibility.Collapsed;
            }
            else
            {
                FlowerImage.Source = null;
                NoImageText.Visibility = Visibility.Visible;
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ShortNameBox.Text) || CategoryBox.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, заполните обязательные поля.");
                return;
            }

            if (!decimal.TryParse(PriceBox.Text, out decimal price))
            {
                MessageBox.Show("Введите корректную цену.");
                return;
            }

            if (!int.TryParse(QuantityBox.Text, out int quantity))
            {
                MessageBox.Show("Введите корректное количество.");
                return;
            }

            _flower.ShortName = ShortNameBox.Text;
            _flower.FullName = FullName;
            _flower.Description = DescriptionBox.Text;
            _flower.CategoryId = ((Category)CategoryBox.SelectedItem).Id;
            _flower.Price = price;
            _flower.Quantity = quantity;
            _flower.IsOutOfStock = OutOfStockCheck.IsChecked == true;

            if (_currentImage != null)
            {
                _context.FlowerImages.Remove(_currentImage);
                _flower.Images.Remove(_currentImage);
                _currentImage = null;
            }

            if (_selectedImageData != null)
            {
                var newImage = new FlowerImage { ImageData = _selectedImageData, Flower = _flower };
                _flower.Images.Add(newImage);
                _context.FlowerImages.Add(newImage);
            }

            if (_isNew)
            {
                _context.Flowers.Add(_flower);
            }

            _context.SaveChanges();
            DialogResult = true;
            Close();
        }

        private void LoadImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp"
            };
            if (dialog.ShowDialog() == true)
            {
                _selectedImage = new BitmapImage(new Uri(dialog.FileName));
                FlowerImage.Source = _selectedImage;
                _selectedImageData = ImageConverter.ImageToByte(_selectedImage);
                NoImageText.Visibility = Visibility.Collapsed;
            }
        }

        private void ClearImageCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            FlowerImage.Source = null;
            _selectedImage = null;
            _selectedImageData = null;
            NoImageText.Visibility = Visibility.Visible;
        }

        private void ClearImageCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = _selectedImageData != null;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }

    public class ContainsMinusConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var str = value as string;
            return !string.IsNullOrEmpty(str) && str.Contains("-");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
