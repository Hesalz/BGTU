﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using FlowerShopWPF.Models;

namespace FlowerShopWPF.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        internal FlowerContext _context = new FlowerContext();

        private Stack<IUndoableAction> undoStack = new Stack<IUndoableAction>();
        private Stack<IUndoableAction> redoStack = new Stack<IUndoableAction>();

        public ICommand UndoCommand { get; }
        public ICommand RedoCommand { get; }
        public ObservableCollection<Flower> Flowers { get; set; }
        public ObservableCollection<Category> Categories { get; set; }

        private ObservableCollection<Flower> _filteredFlowers;
        public ObservableCollection<Flower> FilteredFlowers
        {
            get => _filteredFlowers;
            set { _filteredFlowers = value; OnPropertyChanged(nameof(FilteredFlowers)); }
        }

        private Flower _selectedFlower;
        public Flower SelectedFlower
        {
            get => _selectedFlower;
            set { _selectedFlower = value; OnPropertyChanged(nameof(SelectedFlower)); }
        }

        private string _searchText;
        public string SearchText
        {
            get => _searchText;
            set { _searchText = value; OnPropertyChanged(nameof(SearchText)); FilterFlowers(); }
        }

        private Category _selectedCategory;
        public Category SelectedCategory
        {
            get => _selectedCategory;
            set { _selectedCategory = value; OnPropertyChanged(nameof(SelectedCategory)); FilterFlowers(); }
        }

        private decimal? _priceFrom;
        public decimal? PriceFrom
        {
            get => _priceFrom;
            set { _priceFrom = value; OnPropertyChanged(nameof(PriceFrom)); FilterFlowers(); }
        }

        private decimal? _priceTo;
        public decimal? PriceTo
        {
            get => _priceTo;
            set { _priceTo = value; OnPropertyChanged(nameof(PriceTo)); FilterFlowers(); }
        }

        private string _priceFromText;
        public string PriceFromText
        {
            get => _priceFromText;
            set
            {
                _priceFromText = value;
                if (decimal.TryParse(value, out decimal result))
                    PriceFrom = result;
                else
                    PriceFrom = null;
                OnPropertyChanged(nameof(PriceFromText));
                FilterFlowers();
            }
        }

        private string _priceToText;
        public string PriceToText
        {
            get => _priceToText;
            set
            {
                _priceToText = value;
                if (decimal.TryParse(value, out decimal result))
                    PriceTo = result;
                else
                    PriceTo = null;
                OnPropertyChanged(nameof(PriceToText));
                FilterFlowers();
            }
        }

        public ICommand AddFlowerCommand { get; }
        public ICommand EditFlowerCommand { get; }
        public ICommand DeleteFlowerCommand { get; }

        public MainViewModel()
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    _context.Categories.Load();
                    _context.Flowers.Include(f => f.Category).Include(f => f.Images).Load();

                    Flowers = new ObservableCollection<Flower>(_context.Flowers.Local);
                    Categories = new ObservableCollection<Category>(_context.Categories.Local);

                    if (!Categories.Any(c => c.Id == 0))
                        Categories.Insert(0, new Category { Id = 0, Name = "Все" });

                    FilteredFlowers = new ObservableCollection<Flower>(Flowers);
                    SelectedCategory = Categories.FirstOrDefault();

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
                }
            }

            AddFlowerCommand = new RelayCommand(_ => OpenDetailsWindow(null));
            EditFlowerCommand = new RelayCommand(_ => OpenDetailsWindow(SelectedFlower), _ => SelectedFlower != null);
            DeleteFlowerCommand = new RelayCommand(_ => DeleteFlower(), _ => SelectedFlower != null);
            UndoCommand = new RelayCommand(_ => Undo(), _ => undoStack.Any());
            RedoCommand = new RelayCommand(_ => Redo(), _ => redoStack.Any());
        }

        private void OpenDetailsWindow(Flower flower)
        {
            Flower beforeEdit = null;
            if (flower != null)
                beforeEdit = CloneFlower(flower);

            var window = new Views.FlowerDetailsWindow(_context, flower);
            if (window.ShowDialog() == true)
            {
                using (var transaction = _context.Database.BeginTransaction())
                {
                    try
                    {
                        _context.Flowers.Include(f => f.Category).Include(f => f.Images).Load();

                        Flowers.Clear();
                        foreach (var f in _context.Flowers.Local)
                            Flowers.Add(f);

                        FilterFlowers();

                        if (flower == null)
                        {
                            var newFlower = Flowers.LastOrDefault();
                            if (newFlower != null)
                            {
                                undoStack.Push(new AddFlowerAction(newFlower));
                                redoStack.Clear();
                            }
                        }
                        else
                        {
                            var afterEdit = Flowers.FirstOrDefault(f => f.Id == beforeEdit.Id);
                            if (afterEdit != null)
                            {
                                undoStack.Push(new EditFlowerAction(beforeEdit, CloneFlower(afterEdit)));
                                redoStack.Clear();
                            }
                            else
                            {
                                FilterFlowers();
                            }
                        }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"Ошибка при сохранении изменений: {ex.Message}");
                    }
                }
            }
        }

        private Flower CloneFlower(Flower flower)
        {
            return new Flower
            {
                Id = flower.Id,
                ShortName = flower.ShortName,
                FullName = flower.FullName,
                Description = flower.Description,
                CategoryId = flower.CategoryId,
                Rating = flower.Rating,
                Price = flower.Price,
                Quantity = flower.Quantity,
                Color = flower.Color,
                Size = flower.Size,
                CountryOfDelivery = flower.CountryOfDelivery,
                Discount = flower.Discount,
                IsOutOfStock = flower.IsOutOfStock,
                PurchasedCount = flower.PurchasedCount,
                Manufacturer = flower.Manufacturer,
                Images = flower.Images?.Select(img => new FlowerImage
                {
                    Id = img.Id,
                    ImageData = img.ImageData != null ? (byte[])img.ImageData.Clone() : null
                }).ToList()
            };
        }

        public void FilterFlowers()
        {
            IQueryable<Flower> query = _context.Flowers.Include(f => f.Category).Include(f => f.Images);

            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                var lowerSearch = SearchText.ToLower();
                query = query.Where(f => f.ShortName != null && f.ShortName.ToLower().Contains(lowerSearch));
            }

            if (SelectedCategory != null && SelectedCategory.Id != 0)
                query = query.Where(f => f.CategoryId == SelectedCategory.Id);

            if (PriceFrom.HasValue)
                query = query.Where(f => f.Price >= PriceFrom.Value);

            if (PriceTo.HasValue)
                query = query.Where(f => f.Price <= PriceTo.Value);

            FilteredFlowers = new ObservableCollection<Flower>(query.ToList());
        }

        private void DeleteFlower()
        {
            if (SelectedFlower == null) return;

            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    var flowerToDelete = _context.Flowers.Include(f => f.Images).FirstOrDefault(f => f.Id == SelectedFlower.Id);
                    if (flowerToDelete != null)
                    {
                        var action = new DeleteFlowerAction(CloneFlower(flowerToDelete));

                        foreach (var img in flowerToDelete.Images.ToList())
                            _context.FlowerImages.Remove(img);

                        _context.Flowers.Remove(flowerToDelete);
                        _context.SaveChanges();

                        Flowers.Remove(SelectedFlower);
                        FilterFlowers();

                        undoStack.Push(action);
                        redoStack.Clear();
                    }
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show($"Ошибка при удалении: {ex.Message}");
                }
            }
        }

        private void Undo()
        {
            if (undoStack.Any())
            {
                var action = undoStack.Pop();
                action.Undo(this);
                redoStack.Push(action);
            }
        }

        private void Redo()
        {
            if (redoStack.Any())
            {
                var action = redoStack.Pop();
                action.Redo(this);
                undoStack.Push(action);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public interface IUndoableAction
    {
        void Undo(MainViewModel vm);
        void Redo(MainViewModel vm);
    }

    public class AddFlowerAction : IUndoableAction
    {
        private Flower _flower;

        public AddFlowerAction(Flower flower)
        {
            _flower = flower;
        }

        public void Undo(MainViewModel vm)
        {
            var flower = vm._context.Flowers.Include(f => f.Images).FirstOrDefault(f => f.Id == _flower.Id);
            if (flower != null)
            {
                foreach (var img in flower.Images.ToList())
                    vm._context.FlowerImages.Remove(img);

                vm._context.Flowers.Remove(flower);
                vm._context.SaveChanges();

                var toRemove = vm.Flowers.FirstOrDefault(f => f.Id == _flower.Id);
                if (toRemove != null)
                    vm.Flowers.Remove(toRemove);

                vm.FilterFlowers();
            }
        }

        public void Redo(MainViewModel vm)
        {
            var flowerCopy = new Flower
            {
                ShortName = _flower.ShortName,
                FullName = _flower.FullName,
                Description = _flower.Description,
                CategoryId = _flower.CategoryId,
                Rating = _flower.Rating,
                Price = _flower.Price,
                Quantity = _flower.Quantity,
                Color = _flower.Color,
                Size = _flower.Size,
                CountryOfDelivery = _flower.CountryOfDelivery,
                Discount = _flower.Discount,
                IsOutOfStock = _flower.IsOutOfStock,
                PurchasedCount = _flower.PurchasedCount,
                Manufacturer = _flower.Manufacturer
            };
            vm._context.Flowers.Add(flowerCopy);
            vm._context.SaveChanges();

            if (_flower.Images != null)
            {
                foreach (var img in _flower.Images)
                {
                    var imgCopy = new FlowerImage
                    {
                        ImageData = img.ImageData != null ? (byte[])img.ImageData.Clone() : null,
                        FlowerId = flowerCopy.Id
                    };
                    vm._context.FlowerImages.Add(imgCopy);
                }
                vm._context.SaveChanges();
            }

            vm.Flowers.Add(flowerCopy);
            vm.FilterFlowers();
        }
    }

    public class DeleteFlowerAction : IUndoableAction
    {
        private Flower _flower;

        public DeleteFlowerAction(Flower flower)
        {
            _flower = flower;
        }

        public void Undo(MainViewModel vm)
        {
            var flowerCopy = new Flower
            {
                ShortName = _flower.ShortName,
                FullName = _flower.FullName,
                Description = _flower.Description,
                CategoryId = _flower.CategoryId,
                Rating = _flower.Rating,
                Price = _flower.Price,
                Quantity = _flower.Quantity,
                Color = _flower.Color,
                Size = _flower.Size,
                CountryOfDelivery = _flower.CountryOfDelivery,
                Discount = _flower.Discount,
                IsOutOfStock = _flower.IsOutOfStock,
                PurchasedCount = _flower.PurchasedCount,
                Manufacturer = _flower.Manufacturer
            };
            vm._context.Flowers.Add(flowerCopy);
            vm._context.SaveChanges();

            if (_flower.Images != null)
            {
                foreach (var img in _flower.Images)
                {
                    var imgCopy = new FlowerImage
                    {
                        ImageData = img.ImageData != null ? (byte[])img.ImageData.Clone() : null,
                        FlowerId = flowerCopy.Id
                    };
                    vm._context.FlowerImages.Add(imgCopy);
                }
                vm._context.SaveChanges();
            }

            vm.Flowers.Add(flowerCopy);
            vm.FilterFlowers();
        }

        public void Redo(MainViewModel vm)
        {
            var flowerToDelete = vm._context.Flowers.Include(f => f.Images).FirstOrDefault(f => f.ShortName == _flower.ShortName && f.FullName == _flower.FullName);
            if (flowerToDelete != null)
            {
                foreach (var img in flowerToDelete.Images.ToList())
                    vm._context.FlowerImages.Remove(img);

                vm._context.Flowers.Remove(flowerToDelete);
                vm._context.SaveChanges();

                var toRemove = vm.Flowers.FirstOrDefault(f => f.Id == flowerToDelete.Id);
                if (toRemove != null)
                    vm.Flowers.Remove(toRemove);

                vm.FilterFlowers();
            }
        }
    }

    public class EditFlowerAction : IUndoableAction
    {
        private Flower _beforeEdit;
        private Flower _afterEdit;

        public EditFlowerAction(Flower beforeEdit, Flower afterEdit)
        {
            _beforeEdit = beforeEdit;
            _afterEdit = afterEdit;
        }

        public void Undo(MainViewModel vm)
        {
            ApplyState(vm, _beforeEdit);
        }

        public void Redo(MainViewModel vm)
        {
            ApplyState(vm, _afterEdit);
        }

        private void ApplyState(MainViewModel vm, Flower state)
        {
            var flower = vm._context.Flowers.Include(f => f.Images).FirstOrDefault(f => f.Id == state.Id);
            if (flower == null) return;

            flower.ShortName = state.ShortName;
            flower.FullName = state.FullName;
            flower.Description = state.Description;
            flower.CategoryId = state.CategoryId;
            flower.Rating = state.Rating;
            flower.Price = state.Price;
            flower.Quantity = state.Quantity;
            flower.Color = state.Color;
            flower.Size = state.Size;
            flower.CountryOfDelivery = state.CountryOfDelivery;
            flower.Discount = state.Discount;
            flower.IsOutOfStock = state.IsOutOfStock;
            flower.PurchasedCount = state.PurchasedCount;
            flower.Manufacturer = state.Manufacturer;

            foreach (var img in flower.Images.ToList())
                vm._context.FlowerImages.Remove(img);

            if (state.Images != null)
            {
                foreach (var img in state.Images)
                {
                    var imgCopy = new FlowerImage
                    {
                        ImageData = img.ImageData != null ? (byte[])img.ImageData.Clone() : null,
                        FlowerId = flower.Id
                    };
                    vm._context.FlowerImages.Add(imgCopy);
                }
            }

            vm._context.SaveChanges();

            var existing = vm.Flowers.FirstOrDefault(f => f.Id == flower.Id);
            if (existing != null)
            {
                int index = vm.Flowers.IndexOf(existing);
                vm.Flowers[index] = flower;
            }
            vm.FilterFlowers();
        }
    }
}
