﻿using FlowerShopWPF.ViewModels;

namespace FlowerShopWPF
{
    public interface IUndoableAction
    {
        void Undo(MainViewModel vm);
        void Redo(MainViewModel vm);
    }
}
