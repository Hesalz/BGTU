﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FlowerShopWPF.Commands
{
    public static class CustomCommands
    {
        public static readonly RoutedUICommand ClearImageCommand = new RoutedUICommand(
            "Удалить изображение", 
            "ClearImageCommand", 
            typeof(CustomCommands)  
        );
    }
}
