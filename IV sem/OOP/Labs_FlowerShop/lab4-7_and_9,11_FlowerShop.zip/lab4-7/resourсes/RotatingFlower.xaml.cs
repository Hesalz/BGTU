﻿using System.Windows.Controls;

namespace FlowerShopWPF.Controls
{
    public partial class RotatingFlower : UserControl
    {
        public RotatingFlower()
        {
            InitializeComponent();
        }
    }
}
