﻿using System.Windows;
using Microsoft.Win32;
using System.IO;

namespace SneakShopADO
{
    public partial class AddEditBrandWindow : Window
    {
        public string BrandName { get; private set; }
        public byte[] LogoBytes { get; private set; }

        public AddEditBrandWindow(string name = null, byte[] logo = null)
        {
            InitializeComponent();
            if (name != null) txtName.Text = name;
            if (logo != null) LogoBytes = logo;
        }

        private void ChooseLogo_Click(object sender, RoutedEventArgs e)
        {
            var ofd = new OpenFileDialog { Filter = "Картинки|*.png;*.jpg;*.jpeg;*.bmp" };
            if (ofd.ShowDialog() == true)
            {
                LogoBytes = File.ReadAllBytes(ofd.FileName);
                txtLogoPath.Text = System.IO.Path.GetFileName(ofd.FileName);
            }
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название бренда!");
                return;
            }
            BrandName = txtName.Text;
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
    }
}
