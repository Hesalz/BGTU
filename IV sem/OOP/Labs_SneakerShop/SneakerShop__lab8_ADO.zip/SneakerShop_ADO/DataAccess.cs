﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Threading.Tasks;

namespace SneakShopADO
{
    public static class DataAccess
    {
        public static string MasterConnectionString => ConfigurationManager.ConnectionStrings["MasterConn"].ConnectionString;
        public static string DatabaseConnectionString => ConfigurationManager.ConnectionStrings["SneakShopConn"].ConnectionString;

        public static void EnsureDatabaseAndUser()
        {
            using var connection = new SqlConnection(MasterConnectionString);
            connection.Open();

            string createDbSql = @"
IF DB_ID('SneakShop_ADO') IS NULL
BEGIN
    CREATE DATABASE SneakShop_ADO;
END
";
            using (var cmd = new SqlCommand(createDbSql, connection))
            {
                cmd.ExecuteNonQuery();
            }

            string createTablesSql = @"
USE SneakShop_ADO;

IF OBJECT_ID('Brands', 'U') IS NULL
BEGIN
    CREATE TABLE Brands (
        Id INT IDENTITY PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Logo VARBINARY(MAX) NOT NULL
    );
END

IF OBJECT_ID('Sneakers', 'U') IS NULL
BEGIN
    CREATE TABLE Sneakers (
        Id INT IDENTITY PRIMARY KEY,
        Model NVARCHAR(100) NOT NULL,
        Price MONEY NOT NULL,
        Size FLOAT NOT NULL,
        Photo VARBINARY(MAX) NOT NULL,
        BrandId INT FOREIGN KEY REFERENCES Brands(Id)
    );
END

IF OBJECT_ID('SneakerLog', 'U') IS NULL
BEGIN
    CREATE TABLE SneakerLog (
        LogId INT IDENTITY PRIMARY KEY,
        SneakerId INT,
        InsertedAt DATETIME DEFAULT GETDATE()
    );
END
";
            using (var cmd = new SqlCommand(createTablesSql, connection))
            {
                cmd.ExecuteNonQuery();
            }
            string createTriggerSql = @"
USE SneakShop_ADO;

IF OBJECT_ID('tr_SneakerInsert_Log', 'TR') IS NULL
BEGIN
    EXEC('
    CREATE TRIGGER tr_SneakerInsert_Log
    ON Sneakers
    AFTER INSERT
    AS
    BEGIN
        INSERT INTO SneakerLog (SneakerId)
        SELECT Id FROM INSERTED;
    END
    ');
END
";
            using (var cmd = new SqlCommand(createTriggerSql, connection))
            {
                cmd.ExecuteNonQuery();
            }

            string createProcAddBrand = @"
USE SneakShop_ADO;

IF OBJECT_ID('usp_AddBrand', 'P') IS NULL
BEGIN
    EXEC('
    CREATE PROCEDURE usp_AddBrand
        @Name NVARCHAR(100),
        @Logo VARBINARY(MAX)
    AS
    BEGIN
        IF @Logo IS NULL
            THROW 50000, ''Logo is required.'', 1;

        INSERT INTO Brands (Name, Logo) VALUES (@Name, @Logo);
    END
    ');
END
";
            using (var cmd = new SqlCommand(createProcAddBrand, connection))
            {
                cmd.ExecuteNonQuery();
            }

            string createProcAddSneaker = @"
USE SneakShop_ADO;

IF OBJECT_ID('usp_AddSneaker', 'P') IS NULL
BEGIN
    EXEC('
    CREATE PROCEDURE usp_AddSneaker
        @Model NVARCHAR(100),
        @Price MONEY,
        @Size FLOAT,
        @Photo VARBINARY(MAX),
        @BrandId INT
    AS
    BEGIN
        IF @Photo IS NULL
            THROW 50000, ''Photo is required.'', 1;

        INSERT INTO Sneakers (Model, Price, Size, Photo, BrandId)
        VALUES (@Model, @Price, @Size, @Photo, @BrandId);
    END
    ');
END
";
            using (var cmd = new SqlCommand(createProcAddSneaker, connection))
            {
                cmd.ExecuteNonQuery();
            }
        }

        public static DataTable ExecuteQuery(string sql, SqlParameter[]? parameters = null)
        {
            using var conn = new SqlConnection(DatabaseConnectionString);
            using var cmd = new SqlCommand(sql, conn);
            if (parameters != null)
                cmd.Parameters.AddRange(parameters);
            using var adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }

        public static int ExecuteNonQuery(string sql, SqlParameter[]? parameters = null)
        {
            using var conn = new SqlConnection(DatabaseConnectionString);
            using var cmd = new SqlCommand(sql, conn);
            if (parameters != null)
                ValidateAndAddParameters(cmd, parameters);
            conn.Open();
            return cmd.ExecuteNonQuery();
        }

        public static int ExecuteStoredProcedure(string procedureName, SqlParameter[]? parameters = null)
        {
            using var conn = new SqlConnection(DatabaseConnectionString);
            using var cmd = new SqlCommand(procedureName, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            if (parameters != null)
                ValidateAndAddParameters(cmd, parameters);
            conn.Open();
            return cmd.ExecuteNonQuery();
        }

        public static async Task<DataTable> ExecuteQueryAsync(string query, SqlParameter[] parameters = null)
        {
            var dataTable = new DataTable();

            using var connection = new SqlConnection(DatabaseConnectionString);
            await connection.OpenAsync();

            using var command = new SqlCommand(query, connection);
            if (parameters != null)
            {
                command.Parameters.AddRange(parameters);
            }

            using var reader = await command.ExecuteReaderAsync();
            dataTable.Load(reader);
            return dataTable;
        }

        public static async Task<int> ExecuteNonQueryAsync(string query, SqlParameter[] parameters = null)
        {
            using var connection = new SqlConnection(DatabaseConnectionString);
            await connection.OpenAsync();

            using var command = new SqlCommand(query, connection);
            if (parameters != null)
            {
                command.Parameters.AddRange(parameters);
            }

            return await command.ExecuteNonQueryAsync();
        }

        private static void ValidateAndAddParameters(SqlCommand cmd, SqlParameter[] parameters)
        {
            foreach (var param in parameters)
            {
                if ((param.ParameterName.Equals("@Logo", StringComparison.OrdinalIgnoreCase) ||
                     param.ParameterName.Equals("@Photo", StringComparison.OrdinalIgnoreCase)) &&
                    (param.Value == null || param.Value == DBNull.Value))
                {
                    MessageBox.Show(
                        $"Параметр {param.ParameterName} обязателен и не может быть пустым.",
                        "Ошибка ввода данных",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    throw new ArgumentException($"Параметр {param.ParameterName} обязателен и не может быть пустым.");
                }

                if ((param.SqlDbType == SqlDbType.VarBinary || param.SqlDbType == SqlDbType.Image) &&
                    param.Value is string)
                {
                    MessageBox.Show(
                        $"Параметр {param.ParameterName} должен быть типа byte[], а не string.",
                        "Ошибка ввода данных",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    throw new ArgumentException($"Параметр {param.ParameterName} должен быть типа byte[], а не string.");
                }

                cmd.Parameters.Add(param);
            }
        }
    }
}
