﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace SneakShopADO
{
    public partial class MainWindow : Window
    {
        private DataTable currentTable;
        private string currentView = "Brands";

        public MainWindow()
        {
            DatabaseHelper.EnsureDatabaseExists();
            InitializeComponent();
            DataAccess.EnsureDatabaseAndUser();
            _ = LoadBrandsAsync();
        }

        private async Task LoadBrandsAsync()
        {
            currentView = "Brands";
            string sql = "SELECT Id, Name, Logo FROM Brands";
            currentTable = await DataAccess.ExecuteQueryAsync(sql);

            ConfigureBrandColumns();
            DataGridMain.ItemsSource = currentTable.DefaultView;
        }

        private async Task LoadSneakersAsync()
        {
            currentView = "Sneakers";
            string sql = @"SELECT s.Id, s.Model, s.Price, s.Size, s.Photo, s.BrandId, b.Name AS BrandName 
                           FROM Sneakers s
                           LEFT JOIN Brands b ON s.BrandId = b.Id";
            currentTable = await DataAccess.ExecuteQueryAsync(sql);

            ConfigureSneakerColumns();
            DataGridMain.ItemsSource = currentTable.DefaultView;
        }

        private void ConfigureBrandColumns()
        {
            DataGridMain.Columns.Clear();
            DataGridMain.Columns.Add(new DataGridTextColumn { Header = "Id", Binding = new System.Windows.Data.Binding("Id"), Width = 50 });
            DataGridMain.Columns.Add(new DataGridTextColumn { Header = "Название", Binding = new System.Windows.Data.Binding("Name"), Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
            DataGridMain.Columns.Add(new DataGridTemplateColumn { Header = "Логотип", Width = 120, CellTemplate = (DataTemplate)Resources["LogoCellTemplate"] });
        }

        private void ConfigureSneakerColumns()
        {
            DataGridMain.Columns.Clear();
            DataGridMain.Columns.Add(new DataGridTextColumn { Header = "Id", Binding = new System.Windows.Data.Binding("Id"), Width = 50 });
            DataGridMain.Columns.Add(new DataGridTextColumn { Header = "Модель", Binding = new System.Windows.Data.Binding("Model"), Width = 150 });
            DataGridMain.Columns.Add(new DataGridTextColumn { Header = "Цена", Binding = new System.Windows.Data.Binding("Price"), Width = 80 });
            DataGridMain.Columns.Add(new DataGridTextColumn { Header = "Размер", Binding = new System.Windows.Data.Binding("Size"), Width = 80 });
            DataGridMain.Columns.Add(new DataGridTextColumn { Header = "Бренд", Binding = new System.Windows.Data.Binding("BrandName"), Width = 120 });
            DataGridMain.Columns.Add(new DataGridTemplateColumn { Header = "Фото", Width = 120, CellTemplate = (DataTemplate)Resources["PhotoCellTemplate"] });
        }

        private async void LoadBrands(object sender, RoutedEventArgs e) => await LoadBrandsAsync();
        private async void LoadSneakers(object sender, RoutedEventArgs e) => await LoadSneakersAsync();

        private async void AddItem(object sender, RoutedEventArgs e)
        {
            try
            {
                using var conn = new SqlConnection(DataAccess.DatabaseConnectionString);
                await conn.OpenAsync();
                using var transaction = conn.BeginTransaction();

                if (currentView == "Brands")
                {
                    var dlg = new AddEditBrandWindow();
                    if (dlg.ShowDialog() == true)
                    {
                        var sql = "INSERT INTO Brands (Name, Logo) VALUES (@Name, @Logo)";
                        using var cmd = new SqlCommand(sql, conn, transaction);
                        cmd.Parameters.AddWithValue("@Name", dlg.BrandName);
                        cmd.Parameters.AddWithValue("@Logo", dlg.LogoBytes ?? (object)DBNull.Value);
                        await cmd.ExecuteNonQueryAsync();
                        transaction.Commit();
                        await LoadBrandsAsync();
                    }
                    else transaction.Rollback();
                }
                else
                {
                    var dlg = new AddEditSneakerWindow();
                    if (dlg.ShowDialog() == true)
                    {
                        var sql = "INSERT INTO Sneakers (Model, Price, Size, Photo, BrandId) VALUES (@Model, @Price, @Size, @Photo, @BrandId)";
                        using var cmd = new SqlCommand(sql, conn, transaction);
                        cmd.Parameters.AddWithValue("@Model", dlg.ModelName);
                        cmd.Parameters.AddWithValue("@Price", dlg.Price);
                        cmd.Parameters.AddWithValue("@Size", dlg.Size);
                        cmd.Parameters.AddWithValue("@Photo", dlg.PhotoBytes ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@BrandId", dlg.BrandId);
                        await cmd.ExecuteNonQueryAsync();
                        transaction.Commit();
                        await LoadSneakersAsync();
                    }
                    else transaction.Rollback();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void DeleteItem(object sender, RoutedEventArgs e)
        {
            if (DataGridMain.SelectedItem == null)
            {
                MessageBox.Show("Выберите элемент для удаления.");
                return;
            }

            if (MessageBox.Show("Удалить выбранную запись?", "Подтвердите", MessageBoxButton.YesNo) != MessageBoxResult.Yes)
                return;

            try
            {
                DataRowView row = (DataRowView)DataGridMain.SelectedItem;
                int id = Convert.ToInt32(row["Id"]);
                string table = currentView == "Brands" ? "Brands" : "Sneakers";

                using var conn = new SqlConnection(DataAccess.DatabaseConnectionString);
                await conn.OpenAsync();
                using var transaction = conn.BeginTransaction();

                var sql = $"DELETE FROM {table} WHERE Id = @Id";
                using var cmd = new SqlCommand(sql, conn, transaction);
                cmd.Parameters.AddWithValue("@Id", id);
                await cmd.ExecuteNonQueryAsync();

                transaction.Commit();
                MessageBox.Show("Запись удалена.");
                if (table == "Brands") await LoadBrandsAsync();
                else await LoadSneakersAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void DataGridMain_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (DataGridMain.SelectedItem == null) return;

            DataRowView row = (DataRowView)DataGridMain.SelectedItem;

            try
            {
                using var conn = new SqlConnection(DataAccess.DatabaseConnectionString);
                await conn.OpenAsync();
                using var transaction = conn.BeginTransaction();

                if (currentView == "Brands")
                {
                    var dlg = new AddEditBrandWindow(row["Name"].ToString(), row["Logo"] as byte[]);
                    if (dlg.ShowDialog() == true)
                    {
                        string sql = "UPDATE Brands SET Name=@Name, Logo=@Logo WHERE Id=@Id";
                        using var cmd = new SqlCommand(sql, conn, transaction);
                        cmd.Parameters.AddWithValue("@Name", dlg.BrandName);
                        cmd.Parameters.AddWithValue("@Logo", dlg.LogoBytes ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@Id", row["Id"]);
                        await cmd.ExecuteNonQueryAsync();
                        transaction.Commit();
                        await LoadBrandsAsync();
                    }
                    else transaction.Rollback();
                }
                else
                {
                    var dlg = new AddEditSneakerWindow(
                        sneakerId: (int)row["Id"],
                        model: row["Model"].ToString(),
                        price: Convert.ToDecimal(row["Price"]),
                        size: Convert.ToDouble(row["Size"]),
                        brandId: row["BrandId"] != DBNull.Value ? Convert.ToInt32(row["BrandId"]) : (int?)null,
                        photo: row["Photo"] as byte[]
                    );

                    if (dlg.ShowDialog() == true)
                    {
                        string sql = @"UPDATE Sneakers 
                                      SET Model = @Model, 
                                          Price = @Price, 
                                          Size = @Size, 
                                          Photo = @Photo, 
                                          BrandId = @BrandId 
                                      WHERE Id = @Id";

                        using var cmd = new SqlCommand(sql, conn, transaction);
                        cmd.Parameters.AddWithValue("@Id", row["Id"]);
                        cmd.Parameters.AddWithValue("@Model", dlg.ModelName);
                        cmd.Parameters.AddWithValue("@Price", dlg.Price);
                        cmd.Parameters.AddWithValue("@Size", dlg.Size);
                        cmd.Parameters.AddWithValue("@Photo", dlg.PhotoBytes ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@BrandId", dlg.BrandId);
                        await cmd.ExecuteNonQueryAsync();

                        transaction.Commit();
                        await LoadSneakersAsync();
                    }
                    else transaction.Rollback();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}