﻿using System;
using System.Data;
using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace SneakShopADO
{
    public partial class AddEditSneakerWindow : Window
    {
        public string ModelName { get; private set; }
        public decimal Price { get; private set; }
        public double Size { get; private set; }
        public int BrandId { get; private set; }
        public byte[] PhotoBytes { get; private set; }

        public AddEditSneakerWindow(int? sneakerId = null, string model = null, decimal? price = null, double? size = null, int? brandId = null, byte[] photo = null)
        {
            InitializeComponent();

            LoadBrands();

            if (model != null) txtModel.Text = model;
            if (price.HasValue) txtPrice.Text = price.Value.ToString();
            if (size.HasValue) txtSize.Text = size.Value.ToString();
            if (brandId.HasValue) cmbBrands.SelectedValue = brandId.Value;
            if (photo != null) PhotoBytes = photo;
        }

        private void LoadBrands()
        {
            string sql = "SELECT Id, Name FROM Brands";
            DataTable brands = DataAccess.ExecuteQuery(sql);
            cmbBrands.ItemsSource = brands.DefaultView;
        }

        private void ChoosePhoto_Click(object sender, RoutedEventArgs e)
        {
            var ofd = new OpenFileDialog { Filter = "Картинки|*.png;*.jpg;*.jpeg;*.bmp" };
            if (ofd.ShowDialog() == true)
            {
                PhotoBytes = File.ReadAllBytes(ofd.FileName);
                txtPhotoPath.Text = System.IO.Path.GetFileName(ofd.FileName);
            }
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtModel.Text))
            {
                MessageBox.Show("Введите модель!");
                return;
            }
            if (!decimal.TryParse(txtPrice.Text, out decimal price))
            {
                MessageBox.Show("Введите корректную цену!");
                return;
            }
            if (!double.TryParse(txtSize.Text, out double size))
            {
                MessageBox.Show("Введите корректный размер!");
                return;
            }
            if (cmbBrands.SelectedValue == null)
            {
                MessageBox.Show("Выберите бренд!");
                return;
            }

            ModelName = txtModel.Text;
            Price = price;
            Size = size;
            BrandId = (int)cmbBrands.SelectedValue;

            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
    }
}
