﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace SneakShopADO
{
    public static class DatabaseHelper
    {
        private static readonly string DatabaseName = "SneakShop_ADO";
        private static readonly string MasterConnectionString = ConfigurationManager.ConnectionStrings["MasterConn"].ConnectionString;
        private static readonly string TargetConnectionString = ConfigurationManager.ConnectionStrings["SneakShopConn"].ConnectionString;

        public static void EnsureDatabaseExists()
        {
            if (!CanConnectToDatabase(TargetConnectionString))
            {
                Console.WriteLine($"База {DatabaseName} не найдена, создаём...");
                CreateDatabase();
            }
            else
            {
                Console.WriteLine($"База {DatabaseName} доступна.");
            }
        }

        private static bool CanConnectToDatabase(string connectionString)
        {
            try
            {
                using var connection = new SqlConnection(connectionString);
                connection.Open();
                return true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine($"Не удалось подключиться: {ex.Message}");
                return false;
            }
        }

        private static void CreateDatabase()
        {
            var createDbQuery = $"IF DB_ID('{DatabaseName}') IS NULL CREATE DATABASE [{DatabaseName}]";

            using var connection = new SqlConnection(MasterConnectionString);
            connection.Open();

            using var command = new SqlCommand(createDbQuery, connection);
            command.ExecuteNonQuery();

            Console.WriteLine($"База данных {DatabaseName} успешно создана.");
        }
    }
}
