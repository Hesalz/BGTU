﻿using Laba0405.Data;
using Laba0405.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace Laba0405.Services
{
    public class SneakerRepository : ISneakerRepository, IDisposable
    {
        private readonly SneakerDbContext _context;

        public SneakerRepository(SneakerDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<List<Sneaker>> GetAllSneakersAsync()
        {
            return await _context.Sneakers
                .Include(s => s.Category)
                .Include(s => s.Brand)
                .Include(s => s.SneakerSizes)
                .ToListAsync();
        }

        public async Task<List<Sneaker>> GetFilteredSneakersAsync(string searchText, int? categoryId, decimal? minPrice, decimal? maxPrice)
        {
            var query = _context.Sneakers
                .Include(s => s.Category)
                .Include(s => s.Brand)
                .Include(s => s.SneakerSizes)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchText))
            {
                query = query.Where(s => s.ShortName.Contains(searchText) ||
                                 s.FullName.Contains(searchText) ||
                                 s.Description.Contains(searchText));
            }

            if (categoryId.HasValue && categoryId.Value > 0)
            {
                query = query.Where(s => s.CategoryId == categoryId.Value);
            }

            if (minPrice.HasValue)
            {
                query = query.Where(s => s.Price >= minPrice.Value);
            }

            if (maxPrice.HasValue)
            {
                query = query.Where(s => s.Price <= maxPrice.Value);
            }

            return await query.ToListAsync();
        }

        public async Task<List<Category>> GetAllCategoriesAsync()
        {
            return await _context.Categories.ToListAsync();
        }

        public async Task<List<Brand>> GetAllBrandsAsync()
        {
            return await _context.Brands.ToListAsync();
        }

        public async Task<Sneaker> AddSizeToSneakerAsync(int sneakerId, double size)
        {
            var sneaker = await _context.Sneakers
                .Include(s => s.SneakerSizes)
                .FirstOrDefaultAsync(s => s.Id == sneakerId);

            if (sneaker != null && !sneaker.SneakerSizes.Any(s => s.Size == size))
            {
                var sneakerSize = new SneakerSize { SneakerId = sneakerId, Size = size };
                _context.SneakerSizes.Add(sneakerSize);
            }

            return await _context.Sneakers
                .Include(s => s.Category)
                .Include(s => s.Brand)
                .Include(s => s.SneakerSizes)
                .FirstOrDefaultAsync(s => s.Id == sneakerId);
        }

        public async Task<Sneaker> RemoveSizeFromSneakerAsync(int sneakerId, double size)
        {
            var sizeEntity = await _context.SneakerSizes
                .FirstOrDefaultAsync(s => s.SneakerId == sneakerId && s.Size == size);

            if (sizeEntity != null)
            {
                _context.SneakerSizes.Remove(sizeEntity);
            }

            return await _context.Sneakers
                .Include(s => s.Category)
                .Include(s => s.Brand)
                .Include(s => s.SneakerSizes)
                .FirstOrDefaultAsync(s => s.Id == sneakerId);
        }

        public async Task AddSneakerAsync(Sneaker sneaker)
        {
            _context.Sneakers.Add(sneaker);
        }

        public async Task UpdateSneakerAsync(Sneaker sneaker)
        {
            var existing = await _context.Sneakers
                .Include(s => s.SneakerSizes)
                .FirstOrDefaultAsync(s => s.Id == sneaker.Id);

            if (existing != null)
            {
                _context.Entry(existing).CurrentValues.SetValues(sneaker);
                existing.CategoryId = sneaker.CategoryId;
                existing.BrandId = sneaker.BrandId;
            }
        }

        public async Task DeleteSneakerAsync(int id)
        {
            var sneaker = await _context.Sneakers.FindAsync(id);
            if (sneaker != null)
            {
                _context.Sneakers.Remove(sneaker);
            }
        }

        public void Dispose()
        {
            _context?.Dispose();
        }
    }
}