﻿using Laba0405.Models;

public interface ISneakerRepository : IDisposable
{
    Task<List<Sneaker>> GetAllSneakersAsync();
    Task<List<Sneaker>> GetFilteredSneakersAsync(string searchText, int? categoryId, decimal? minPrice, decimal? maxPrice);
    Task<List<Category>> GetAllCategoriesAsync();
    Task<List<Brand>> GetAllBrandsAsync();
    Task<Sneaker> AddSizeToSneakerAsync(int sneakerId, double size);
    Task<Sneaker> RemoveSizeFromSneakerAsync(int sneakerId, double size);
    Task AddSneakerAsync(Sneaker sneaker);
    Task UpdateSneakerAsync(Sneaker sneaker);
    Task DeleteSneakerAsync(int id);
}