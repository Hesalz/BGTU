﻿using System.Collections.Generic;
using System.Data.Entity;
using Laba0405.Models;

namespace Laba0405.Data
{
        public class SneakerDbContext : DbContext, IUnitOfWork
        {
            public SneakerDbContext() : base("name=SneakerDbContext")
            {
                Database.SetInitializer(new SneakerDbInitializer());
            }

            public DbSet<Sneaker> Sneakers { get; set; }
            public DbSet<Category> Categories { get; set; }
            public DbSet<Brand> Brands { get; set; }
            public DbSet<SneakerSize> SneakerSizes { get; set; }

            protected override void OnModelCreating(DbModelBuilder modelBuilder)
            {
                modelBuilder.Entity<Sneaker>()
                    .HasRequired(s => s.Category)
                    .WithMany(c => c.Sneakers)
                    .HasForeignKey(s => s.CategoryId);

                modelBuilder.Entity<Sneaker>()
                    .HasRequired(s => s.Brand)
                    .WithMany(b => b.Sneakers)
                    .HasForeignKey(s => s.BrandId);

                modelBuilder.Entity<Sneaker>()
                    .HasMany(s => s.SneakerSizes)
                    .WithRequired(ss => ss.Sneaker)
                    .HasForeignKey(ss => ss.SneakerId);

                base.OnModelCreating(modelBuilder);
            }

            public async Task<int> SaveChangesAsync()
            {
                return await base.SaveChangesAsync();
            }

            public void BeginTransaction()
            {
                Database.BeginTransaction();
            }

            public void CommitTransaction()
            {
                Database.CurrentTransaction?.Commit();
            }

            public void RollbackTransaction()
            {
                Database.CurrentTransaction?.Rollback();
            }
        }
        public class SneakerDbInitializer : CreateDatabaseIfNotExists<SneakerDbContext>
    {
        protected override void Seed(SneakerDbContext context)
        {
            var nike = new Brand { Name = "Nike", Description = "American multinational corporation" };
            var puma = new Brand { Name = "Puma", Description = "German multinational corporation" };
            var vans = new Brand { Name = "Vans", Description = "American skateboarding shoes" };
            var adidas = new Brand { Name = "Adidas", Description = "German multinational corporation" };

            context.Brands.AddRange(new List<Brand> { nike, puma, vans, adidas });

            var casual = new Category { Name = "Повседневные" };
            var running = new Category { Name = "Беговые" };
            var basketball = new Category { Name = "Баскетбольные" };

            context.Categories.AddRange(new List<Category> { casual, running, basketball });
            context.SaveChanges();

            var sneakers = new List<Sneaker>
            {
                new Sneaker
                {
                    ShortName = "Air Max 90",
                    FullName = "Nike Air Max 90",
                    Description = "Классические кроссовки с технологией Air",
                    Price = 12000,
                    Rating = 4.8,
                    StockQuantity = 15,
                    BrandId = nike.Id,
                    CategoryId = casual.Id,
                    MainImage = "https://www.ekinsport.com/media/catalog/product/f/d/fd5810-003_chaussures-nike-air-max-90-gore-tex-gris-bleu-homme-fd5810-003_01.jpg"
                },
                new Sneaker
                {
                    ShortName = "RS-X",
                    FullName = "Puma RS-X",
                    Description = "Стильные кроссовки с ретро-дизайном",
                    Price = 8990,
                    Rating = 4.5,
                    StockQuantity = 10,
                    BrandId = puma.Id,
                    CategoryId = casual.Id,
                    MainImage = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSaElaxuIFdxCnUMQ2A4Rh4BuxQfFX42uAsaw&s"
                },
                new Sneaker
                {
                    ShortName = "Old Skool",
                    FullName = "Vans Old Skool",
                    Description = "Легендарные скейтерские кроссовки",
                    Price = 5990,
                    Rating = 4.7,
                    StockQuantity = 20,
                    BrandId = vans.Id,
                    CategoryId = casual.Id,
                    MainImage = "https://static.ftshp.digital/img/p/1/0/9/5/4/5/1/1095451-full_product.jpg"
                },
                new Sneaker
                {
                    ShortName = "Ultraboost",
                    FullName = "Adidas Ultraboost 21",
                    Description = "Беговые кроссовки с технологией Boost",
                    Price = 14990,
                    Rating = 4.9,
                    StockQuantity = 8,
                    BrandId = adidas.Id,
                    CategoryId = running.Id,
                    MainImage = "https://www.cdiscount.com/pdt2/8/8/7/1/700x700/mp57367887/rw/chaussures-adidas-ultraboost-21-primeblue-bleu-h.jpg"
                },
                new Sneaker
                {
                    ShortName = "Air Jordan",
                    FullName = "Nike Air Jordan 1",
                    Description = "Культовые баскетбольные кроссовки",
                    Price = 15990,
                    Rating = 4.9,
                    StockQuantity = 5,
                    BrandId = nike.Id,
                    CategoryId = basketball.Id,
                    MainImage = "https://www.footlocker.my/media/catalog/product/0/1/0198-NIK55355816100W10H-1.jpg?optimize=medium&bg-color=255,255,255&fit=bounds&height=1200&width=1200&canvas=1200:1200"
                },
                new Sneaker
                {
                    ShortName = "Court Vision",
                    FullName = "Nike Court Vision Low",
                    Description = "Кроссовки в стиле 80-х",
                    Price = 7990,
                    Rating = 4.3,
                    StockQuantity = 12,
                    BrandId = nike.Id,
                    CategoryId = casual.Id,
                    MainImage = "https://static.nike.com/a/images/t_PDP_936_v1/f_auto,q_auto:eco/29a58cdc-d85a-4f01-a226-ede927c8c881/W+NIKE+COURT+VISION+LO+NN.png"
                },
                new Sneaker
                {
                    ShortName = "Classic",
                    FullName = "Puma Classic",
                    Description = "Ретро-кроссовки с классическим дизайном",
                    Price = 6990,
                    Rating = 4.2,
                    StockQuantity = 7,
                    BrandId = puma.Id,
                    CategoryId = casual.Id,
                    MainImage = "https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_2000,h_2000/global/399781/01/sv01/fnd/EEA/fmt/png/Sneakers-Suede-Classic"
                }
            };

            context.Sneakers.AddRange(sneakers);
            context.SaveChanges();

            var sizes = new List<(string ShortName, double[] SizeArray)>
            {
                ("Air Max 90", new[] { 39.0, 40.0, 41.0, 42.0, 43.0, 44.0 }),
                ("RS-X", new[] { 38.0, 39.0, 40.0, 41.0, 42.0 }),
                ("Old Skool", new[] { 37.0, 38.0, 39.0, 40.0, 41.0, 42.0 }),
                ("Ultraboost", new[] { 40.0, 41.0, 42.0, 43.0, 44.0 }),
                ("Air Jordan", new[] { 40.0, 41.0, 42.0, 43.0 }),
                ("Court Vision", new[] { 38.0, 39.0, 40.0, 41.0, 42.0 }),
                ("Classic", new[] { 37.0, 38.0, 39.0, 40.0 })
            };

            foreach (var pair in sizes)
            {
                var sneaker = context.Sneakers.FirstOrDefault(s => s.ShortName == pair.ShortName);
                if (sneaker != null)
                {
                    foreach (var size in pair.SizeArray)
                    {
                        context.SneakerSizes.Add(new SneakerSize
                        {
                            SneakerId = sneaker.Id,
                            Size = size
                        });
                    }
                }
            }
            context.SaveChanges();
        }
    }
}
