﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Laba0405
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static string role;
    }

}
