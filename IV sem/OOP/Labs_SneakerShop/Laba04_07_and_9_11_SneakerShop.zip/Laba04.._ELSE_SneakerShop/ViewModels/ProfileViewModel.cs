﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows;
using Laba0405;
using System.Runtime.CompilerServices;
public class ProfileViewModel : INotifyPropertyChanged
{
    private string _role;
    public string Role
    {
        get => _role;
        set { _role = value; OnPropertyChanged(); }
    }
    public event PropertyChangedEventHandler PropertyChanged;
    protected void OnPropertyChanged([CallerMemberName] string name = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
    public ObservableCollection<Theme> Themes { get; } = new()
    {
        new Theme("Оптимистичная", "Optimistic"),
        new Theme("Розовая", "Pink"),
        new Theme("Серая", "Gray")
    };

    public ObservableCollection<Language> Languages { get; } = new()
    {
        new Language("Русский", "Russian"),
        new Language("English", "English")
    };

    private Theme _selectedTheme;
    public Theme SelectedTheme
    {
        get => _selectedTheme;
        set { _selectedTheme = value; OnPropertyChanged(); }
    }

    private Language _selectedLanguage;
    public Language SelectedLanguage
    {
        get => _selectedLanguage;
        set { _selectedLanguage = value; OnPropertyChanged(); }
    }

    public ICommand SaveCommand { get; }

    public ProfileViewModel()
    {
        Role = MainWindow.role;
        SaveCommand = new RelayCommand(SaveSettings);
        SelectedTheme = Themes.FirstOrDefault();
        SelectedLanguage = Languages.FirstOrDefault();
    }

    private void SaveSettings(object obj)
    {
        ApplyTheme(SelectedTheme);
        ApplyLanguage(SelectedLanguage);
    }

    private void ApplyTheme(Theme theme)
    {
        var dict = new ResourceDictionary
        {
            Source = new Uri($"/Themes/{theme.FileName}.xaml", UriKind.Relative)
        };

        Application.Current.Resources.MergedDictionaries[2] = dict;
    }

    private void ApplyLanguage(Language language)
    {
        var dict = new ResourceDictionary
        {
            Source = new Uri($"/Languages/{language.FileName}.xaml", UriKind.Relative)
        };

        Application.Current.Resources.MergedDictionaries[1] = dict;
    }
}
public class Theme
{
    public string Name { get; }
    public string FileName { get; }

    public Theme(string name, string fileName)
    {
        Name = name;
        FileName = fileName;
    }
}

public class Language
{
    public string Name { get; }
    public string FileName { get; }

    public Language(string name, string fileName)
    {
        Name = name;
        FileName = fileName;
    }
}