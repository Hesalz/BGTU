﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Laba0405.Data;
using Laba0405.Models;
using Laba0405.Services;

namespace Laba0405.ViewModels
{
    public class UserViewModel : INotifyPropertyChanged
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ISneakerRepository _repository;

        public ObservableCollection<Category> Categories { get; } = new ObservableCollection<Category>();
        public ObservableCollection<Sneaker> AllProducts { get; } = new ObservableCollection<Sneaker>();
        public ObservableCollection<Sneaker> FilteredProducts { get; } = new ObservableCollection<Sneaker>();
        public ObservableCollection<Sneaker> CartItems { get; } = new ObservableCollection<Sneaker>();

        private string _searchText;
        public string SearchText
        {
            get => _searchText;
            set { _searchText = value; OnPropertyChanged(); ApplyFilters(); }
        }

        private Category _selectedCategory;
        public Category SelectedCategory
        {
            get => _selectedCategory;
            set { _selectedCategory = value; OnPropertyChanged(); ApplyFilters(); }
        }

        private decimal _minPrice;
        public decimal MinPrice
        {
            get => _minPrice;
            set { _minPrice = value; OnPropertyChanged(); ApplyFilters(); }
        }

        private decimal _maxPrice;
        public decimal MaxPrice
        {
            get => _maxPrice;
            set { _maxPrice = value; OnPropertyChanged(); ApplyFilters(); }
        }

        public decimal TotalPrice => CartItems.Sum(i => i.Price);

        public ICommand AddToCartCommand { get; }
        public ICommand RemoveFromCartCommand { get; }
        public ICommand CheckoutCommand { get; }
        public ICommand OpenProfileCommand { get; }

        public UserViewModel(IUnitOfWork unitOfWork, ISneakerRepository repository)
        {
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));

            AddToCartCommand = new RelayCommand(AddToCart);
            RemoveFromCartCommand = new RelayCommand(RemoveFromCart);
            CheckoutCommand = new RelayCommand(_ => Checkout());
            OpenProfileCommand = new RelayCommand(_ => OpenProfile());

            LoadDataAsync().ConfigureAwait(false);
        }

        private async Task LoadDataAsync()
        {
            try
            {
                var sneakers = await _repository.GetAllSneakersAsync();
                var categories = await _repository.GetAllCategoriesAsync();

                Categories.Clear();
                Categories.Add(new Category { Id = 0, Name = "Все" });

                foreach (var category in categories)
                {
                    Categories.Add(category);
                }

                AllProducts.Clear();
                foreach (var sneaker in sneakers)
                {
                    AllProducts.Add(sneaker);
                }

                SelectedCategory = Categories.FirstOrDefault();
                ApplyFilters();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFilters()
        {
            var filtered = AllProducts.Where(p =>
                (string.IsNullOrWhiteSpace(SearchText) ||
                 p.ShortName.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ||
                 p.FullName.Contains(SearchText, StringComparison.OrdinalIgnoreCase)) &&

                (SelectedCategory.Id == 0 ||
                 p.CategoryId == SelectedCategory.Id) &&

                p.Price >= (MinPrice > 0 ? MinPrice : 0) &&
                p.Price <= (MaxPrice > 0 ? MaxPrice : decimal.MaxValue)
            );

            FilteredProducts.Clear();
            foreach (var item in filtered)
            {
                FilteredProducts.Add(item);
            }
        }

        private void AddToCart(object parameter)
        {
            if (parameter is Sneaker sneaker && !CartItems.Contains(sneaker))
            {
                CartItems.Add(sneaker);
                OnPropertyChanged(nameof(TotalPrice));
            }
        }

        private void RemoveFromCart(object parameter)
        {
            if (parameter is Sneaker sneaker && CartItems.Contains(sneaker))
            {
                CartItems.Remove(sneaker);
                OnPropertyChanged(nameof(TotalPrice));
            }
        }

        private void Checkout()
        {
            MessageBox.Show($"Заказ оформлен! Сумма: {TotalPrice:C}");
            CartItems.Clear();
            OnPropertyChanged(nameof(TotalPrice));
        }

        private void OpenProfile()
        {
            var profileWindow = new ProfileWindow();
            profileWindow.ShowDialog();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}