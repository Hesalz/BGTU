﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Laba0405.Data;
using Laba0405.Models;
using Laba0405.Services;

namespace Laba0405.ViewModels
{
    public class AdminViewModel : INotifyPropertyChanged
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ISneakerRepository _repository;
        private Sneaker _selectedProduct;

        public ObservableCollection<Sneaker> Products { get; } = new ObservableCollection<Sneaker>();
        public ObservableCollection<Category> Categories { get; } = new ObservableCollection<Category>();
        public ObservableCollection<Brand> Brands { get; } = new ObservableCollection<Brand>();

        public Sneaker SelectedProduct
        {
            get => _selectedProduct;
            set
            {
                if (_selectedProduct != value)
                {
                    _selectedProduct = value;
                    _selectedProduct?.RefreshAvailableSizes();
                    OnPropertyChanged();
                    CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        public ICommand AddProductCommand { get; }
        public ICommand EditProductCommand { get; }
        public ICommand DeleteProductCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand UndoCommand { get; }
        public ICommand RedoCommand { get; }
        public ICommand OpenProfileCommand { get; }
        public ICommand AddSizeCommand { get; }
        public ICommand RemoveSizeCommand { get; }

        private readonly Stack<IEnumerable<Sneaker>> _undoStack = new Stack<IEnumerable<Sneaker>>();
        private readonly Stack<IEnumerable<Sneaker>> _redoStack = new Stack<IEnumerable<Sneaker>>();

        private string _newSize;
        public string NewSize
        {
            get => _newSize;
            set
            {
                if (_newSize != value)
                {
                    _newSize = value;
                    OnPropertyChanged();
                }
            }
        }

        private SneakerSize _selectedSize;
        public SneakerSize SelectedSize
        {
            get => _selectedSize;
            set
            {
                if (_selectedSize != value)
                {
                    _selectedSize = value;
                    OnPropertyChanged();
                    CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        public AdminViewModel(IUnitOfWork unitOfWork, ISneakerRepository repository)
        {
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));

            AddProductCommand = new RelayCommand(async _ => await AddProduct());
            EditProductCommand = new RelayCommand(async _ => await EditProduct(), _ => SelectedProduct != null);
            DeleteProductCommand = new RelayCommand(async _ => await DeleteProduct(), _ => SelectedProduct != null);
            OpenProfileCommand = new RelayCommand(_ => OpenProfile());
            SaveCommand = new RelayCommand(async _ => await SaveProducts());
            UndoCommand = new RelayCommand(_ => Undo(), _ => _undoStack.Count > 0);
            RedoCommand = new RelayCommand(_ => Redo(), _ => _redoStack.Count > 0);
            AddSizeCommand = new RelayCommand(async param => await AddSize(param), _ => SelectedProduct != null && !string.IsNullOrWhiteSpace(NewSize));
            RemoveSizeCommand = new RelayCommand(async param => await RemoveSize(param), _ => SelectedProduct != null && SelectedSize != null);

            LoadDataAsync().ConfigureAwait(false);
        }

        private async Task LoadDataAsync()
        {
            try
            {
                var sneakers = await _repository.GetAllSneakersAsync();
                var categories = await _repository.GetAllCategoriesAsync();
                var brands = await _repository.GetAllBrandsAsync();

                Products.Clear();
                foreach (var sneaker in sneakers)
                {
                    sneaker.RefreshAvailableSizes();
                    Products.Add(sneaker);
                }

                Categories.Clear();
                foreach (var category in categories)
                {
                    Categories.Add(category);
                }

                Brands.Clear();
                foreach (var brand in brands)
                {
                    Brands.Add(brand);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveStateForUndo()
        {
            _undoStack.Push(Products.Select(p => p.Clone()).ToList());
            _redoStack.Clear();
            CommandManager.InvalidateRequerySuggested();
        }

        private void OpenProfile()
        {
            var profileWindow = new ProfileWindow();
            profileWindow.ShowDialog();
        }

        private async Task AddProduct()
        {
            try
            {
                SaveStateForUndo();

                var newSneaker = new Sneaker
                {
                    ShortName = "New Sneaker",
                    FullName = "New Full Name",
                    Price = 100,
                    CategoryId = Categories.FirstOrDefault()?.Id ?? 0,
                    BrandId = Brands.FirstOrDefault()?.Id ?? 0,
                    StockQuantity = 0,
                    Rating = 0,
                    Description = string.Empty,
                    MainImage = string.Empty
                };

                await _repository.AddSneakerAsync(newSneaker);
                await _unitOfWork.SaveChangesAsync();

                Products.Add(newSneaker);
                SelectedProduct = newSneaker;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task EditProduct()
        {
            if (SelectedProduct == null) return;

            try
            {
                SaveStateForUndo();
                await _repository.UpdateSneakerAsync(SelectedProduct);
                await _unitOfWork.SaveChangesAsync();

                OnPropertyChanged(nameof(SelectedProduct));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при редактировании товара: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task DeleteProduct()
        {
            if (SelectedProduct == null) return;

            try
            {
                SaveStateForUndo();

                await _repository.DeleteSneakerAsync(SelectedProduct.Id);
                await _unitOfWork.SaveChangesAsync();

                Products.Remove(SelectedProduct);
                SelectedProduct = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task AddSize(object parameter)
        {
            if (SelectedProduct == null || !double.TryParse(NewSize, out double size)) return;

            try
            {
                var updated = await _repository.AddSizeToSneakerAsync(SelectedProduct.Id, size);
                await _unitOfWork.SaveChangesAsync();

                if (updated != null)
                {
                    UpdateProductInCollection(updated);
                    NewSize = string.Empty;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении размера: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task RemoveSize(object parameter)
        {
            if (SelectedProduct == null || SelectedSize == null) return;

            try
            {
                var updated = await _repository.RemoveSizeFromSneakerAsync(SelectedProduct.Id, SelectedSize.Size);
                await _unitOfWork.SaveChangesAsync();

                if (updated != null)
                {
                    UpdateProductInCollection(updated);
                    SelectedSize = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении размера: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateProductInCollection(Sneaker updated)
        {
            var idx = Products.IndexOf(SelectedProduct);
            if (idx >= 0)
            {
                Products[idx] = updated;
                SelectedProduct = updated;
                SelectedProduct.RefreshAvailableSizes();
            }
        }

        public void Undo()
        {
            if (_undoStack.Count == 0) return;

            try
            {
                _unitOfWork.BeginTransaction();

                _redoStack.Push(Products.Select(p => p.Clone()).ToList());
                var previous = _undoStack.Pop();

                var restoredProducts = previous.Except(Products, new SneakerIdComparer()).ToList();

                Products.Clear();
                foreach (var p in previous)
                {
                    Products.Add(p);
                }

                foreach (var product in restoredProducts)
                {
                    _repository.AddSneakerAsync(product).ConfigureAwait(false);
                }

                _unitOfWork.CommitTransaction();
                CommandManager.InvalidateRequerySuggested();
            }
            catch (Exception ex)
            {
                _unitOfWork.RollbackTransaction();
                MessageBox.Show($"Ошибка при отмене действия: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void Redo()
        {
            if (_redoStack.Count == 0) return;

            try
            {
                _unitOfWork.BeginTransaction();

                _undoStack.Push(Products.Select(p => p.Clone()).ToList());
                var next = _redoStack.Pop();

                var removedProducts = Products.Except(next, new SneakerIdComparer()).ToList();

                Products.Clear();
                foreach (var p in next)
                {
                    Products.Add(p);
                }

                foreach (var product in removedProducts)
                {
                    _repository.DeleteSneakerAsync(product.Id).ConfigureAwait(false);
                }

                _unitOfWork.CommitTransaction();
                CommandManager.InvalidateRequerySuggested();
            }
            catch (Exception ex)
            {
                _unitOfWork.RollbackTransaction();
                MessageBox.Show($"Ошибка при повторе действия: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public async Task SaveProducts()
        {
            try
            {
                _unitOfWork.BeginTransaction();

                foreach (var product in Products)
                {
                    await _repository.UpdateSneakerAsync(product);
                }

                await _unitOfWork.SaveChangesAsync();
                _unitOfWork.CommitTransaction();

                MessageBox.Show("Данные успешно сохранены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                _unitOfWork.RollbackTransaction();
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private class SneakerIdComparer : IEqualityComparer<Sneaker>
        {
            public bool Equals(Sneaker x, Sneaker y) => x?.Id == y?.Id;
            public int GetHashCode(Sneaker obj) => obj.Id.GetHashCode();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}