﻿namespace Laba0405.Models
{
    public class Brand
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public virtual ICollection<Sneaker> Sneakers { get; set; }
    }
}