﻿namespace Laba0405.Models
{
    public class SneakerSize
    {
        public int Id { get; set; }
        public double Size { get; set; }

        public int SneakerId { get; set; }
        public virtual Sneaker Sneaker { get; set; }
    }
}
