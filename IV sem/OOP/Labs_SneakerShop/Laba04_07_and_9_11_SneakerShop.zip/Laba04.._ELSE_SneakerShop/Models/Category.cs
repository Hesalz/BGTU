﻿namespace Laba0405.Models
{
    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<Sneaker> Sneakers { get; set; }
    }
}