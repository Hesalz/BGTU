﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Laba0405.Models
{
    public class Sneaker : INotifyPropertyChanged
    {
        public int Id { get; set; }

        private string _shortName;
        public string ShortName
        {
            get => _shortName;
            set { _shortName = value; OnPropertyChanged(); }
        }

        private string _fullName;
        public string FullName
        {
            get => _fullName;
            set { _fullName = value; OnPropertyChanged(); }
        }

        private string _description;
        public string Description
        {
            get => _description;
            set { _description = value; OnPropertyChanged(); }
        }

        private string _mainImage;
        public string MainImage
        {
            get => _mainImage;
            set { _mainImage = value; OnPropertyChanged(); }
        }

        private decimal _price;
        public decimal Price
        {
            get => _price;
            set { _price = value; OnPropertyChanged(); }
        }

        private int _categoryId;
        public int CategoryId
        {
            get => _categoryId;
            set { _categoryId = value; OnPropertyChanged(); }
        }

        private Category _category;
        public virtual Category Category
        {
            get => _category;
            set
            {
                if (_category != value)
                {
                    _category = value;
                    CategoryId = value?.Id ?? 0;
                    OnPropertyChanged();
                }
            }
        }

        private int _brandId;
        public int BrandId
        {
            get => _brandId;
            set { _brandId = value; OnPropertyChanged(); }
        }

        private Brand _brand;
        public virtual Brand Brand
        {
            get => _brand;
            set
            {
                if (_brand != value)
                {
                    _brand = value;
                    BrandId = value?.Id ?? 0;
                    OnPropertyChanged();
                }
            }
        }

        private double _rating;
        public double Rating
        {
            get => _rating;
            set { _rating = value; OnPropertyChanged(); }
        }

        private int _stockQuantity;
        public int StockQuantity
        {
            get => _stockQuantity;
            set { _stockQuantity = value; OnPropertyChanged(); }
        }

        public virtual ICollection<SneakerSize> SneakerSizes { get; set; } = new List<SneakerSize>();

        private ObservableCollection<SneakerSize> _availableSizes = new ObservableCollection<SneakerSize>();
        public ObservableCollection<SneakerSize> AvailableSizes
        {
            get => _availableSizes;
            set
            {
                _availableSizes = value;
                OnPropertyChanged();
            }
        }

        public void RefreshAvailableSizes()
        {
            AvailableSizes.Clear();
            foreach (var size in SneakerSizes.OrderBy(s => s.Size))
                AvailableSizes.Add(size);
        }

        public Sneaker Clone()
        {
            var clone = new Sneaker
            {
                Id = this.Id,
                ShortName = this.ShortName,
                FullName = this.FullName,
                Description = this.Description,
                MainImage = this.MainImage,
                Price = this.Price,
                CategoryId = this.CategoryId,
                BrandId = this.BrandId,
                Rating = this.Rating,
                StockQuantity = this.StockQuantity,
                Category = this.Category,
                Brand = this.Brand,
                SneakerSizes = this.SneakerSizes.Select(s => new SneakerSize
                {
                    Id = s.Id,
                    Size = s.Size,
                    SneakerId = s.SneakerId
                }).ToList()
            };
            clone.RefreshAvailableSizes();
            return clone;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}