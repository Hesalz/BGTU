﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Laba0405.Models;

namespace Laba0405
{
    public partial class SneakerEditForm : UserControl
    {
        public SneakerEditForm()
        {
            InitializeComponent();
        }

        public static readonly DependencyProperty CategoriesProperty =
            DependencyProperty.Register(nameof(Categories),
                                        typeof(IEnumerable<Category>),
                                        typeof(SneakerEditForm),
                                        new PropertyMetadata(null));

        public IEnumerable<Category> Categories
        {
            get => (IEnumerable<Category>)GetValue(CategoriesProperty);
            set => SetValue(CategoriesProperty, value);
        }
    }
}
