﻿using Laba0405.Data;
using Laba0405.Services;
using Laba0405.ViewModels;
using System;
using System.Windows;

namespace Laba0405
{
    public partial class MainWindow : Window
    {
        public static string role = "user";

        public MainWindow()
        {
            try
            {
                var context = new SneakerDbContext();
                if (!context.Database.Exists())
                {
                    context.Database.Initialize(true);
                    MessageBox.Show("База данных была успешно создана.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                }

                var repository = new SneakerRepository(context);
                var unitOfWork = context as IUnitOfWork;

                var input = Microsoft.VisualBasic.Interaction.InputBox(
                    "Выберите под какой ролью вы хотите залогиниться: User/Admin",
                    "Login as...");

                var formatedInput = input.Trim().ToLower().Split(',');

                string lang = "en";

                if (formatedInput.Length > 0)
                    role = formatedInput[0];

                if (formatedInput.Length > 1)
                    lang = formatedInput[1];

                if (lang == "ru")
                {
                    var dict = new ResourceDictionary();
                    dict.Source = new Uri("Russian.xaml", UriKind.Relative);
                    Application.Current.Resources.MergedDictionaries[1] = dict;
                }

                if (role != "admin")
                {
                    UserWindow wnd = new UserWindow(unitOfWork, repository);
                    wnd.Show();
                    this.Close();
                    return;
                }

                InitializeComponent();
                DataContext = new AdminViewModel(unitOfWork, repository);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка запуска приложения: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}