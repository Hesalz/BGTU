﻿using Laba0405.Data;
using Laba0405.Services;
using Laba0405.ViewModels;
using System.Windows;

namespace Laba0405
{
    public partial class UserWindow : Window
    {
        public UserWindow(IUnitOfWork unitOfWork, ISneakerRepository repository)
        {
            InitializeComponent();
            DataContext = new UserViewModel(unitOfWork, repository);
        }
    }
}